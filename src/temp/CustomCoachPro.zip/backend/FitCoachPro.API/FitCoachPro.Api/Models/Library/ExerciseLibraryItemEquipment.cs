namespace FitCoachPro.Api.Models.Library;

public class ExerciseLibraryItemEquipment
{
    public Guid ExerciseLibraryItemId { get; set; }
    public ExerciseLibraryItem Exercise { get; set; } = null!;

    public Guid ExerciseLibraryEquipmentId { get; set; }
    public ExerciseLibraryEquipment Equipment { get; set; } = null!;
}
