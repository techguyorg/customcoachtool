import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, MoreHorizontal, StickyNote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/shared/PageHeader";
import { DataTable, Column } from "@/components/shared/DataTable";
import { useQuery } from "@tanstack/react-query";
import coachService from "@/services/coachService";

type ClientRow = {
  id: string;
  email: string;
  displayName: string;
  startDate?: string;
  currentWeight?: number;
  targetWeight?: number;
  attentionReason?: string | null;
  noteCount?: number;
  latestNotePreview?: string | null;
};

export function ClientsPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");

  const { data: clients = [], isLoading } = useQuery({
    queryKey: ["coach", "clients", { q: search.trim() }],
    queryFn: async () => {
      const q = search.trim();
      if (!q) return coachService.listClients();
      return coachService.searchClients(q);
    },
  });

  const columns: Column<ClientRow>[] = useMemo(
    () => [
      {
        key: "name",
        header: "Client",
        cell: (client) => (
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarFallback className="bg-primary/10 text-primary">
                {client.displayName?.[0]?.toUpperCase() ?? "C"}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="font-medium truncate">{client.displayName}</p>
              <p className="text-sm text-muted-foreground truncate">{client.email}</p>
              {client.latestNotePreview ? (
                <p className="mt-1 text-xs text-muted-foreground truncate flex items-center gap-1">
                  <StickyNote className="h-3 w-3" />
                  {client.latestNotePreview}
                </p>
              ) : null}
            </div>
          </div>
        ),
      },
      {
        key: "weight",
        header: "Progress",
        cell: (client) => {
          const cw = client.currentWeight ?? null;
          const tw = client.targetWeight ?? null;
          return (
            <div className="text-sm">
              <p className="font-medium">{cw !== null ? `${cw} lbs` : "—"}</p>
              <p className="text-muted-foreground">{tw !== null ? `Goal: ${tw} lbs` : "No goal"}</p>
            </div>
          );
        },
      },
      {
        key: "startDate",
        header: "Start Date",
        cell: (client) => (
          <span className="text-sm text-muted-foreground">
            {client.startDate ? new Date(client.startDate).toLocaleDateString() : "—"}
          </span>
        ),
      },
      {
        key: "status",
        header: "Status",
        cell: (client) => (
          <div className="flex flex-wrap items-center gap-2">
            <Badge className="bg-vitality/20 text-vitality border-0">Active</Badge>
            {client.attentionReason ? (
              <Badge variant="secondary" className="bg-energy/20 text-energy border-0">
                {client.attentionReason}
              </Badge>
            ) : null}
            {(client.noteCount ?? 0) > 0 ? (
              <Badge variant="outline" className="text-muted-foreground">
                Notes: {client.noteCount}
              </Badge>
            ) : null}
          </div>
        ),
      },
      {
        key: "actions",
        header: "",
        cell: (client) => (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" onClick={(e) => e.stopPropagation()}>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
              <DropdownMenuItem onClick={() => navigate(`/clients/${client.id}`)}>View Profile</DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`/clients/${client.id}/edit`)}>Edit Profile</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ),
        className: "w-12",
      },
    ],
    [navigate]
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Clients"
        description="Manage your clients and track their progress."
        actions={
          <Button onClick={() => navigate("/clients/new")} className="shadow-energy">
            <Plus className="h-4 w-4 mr-2" />
            Add Client
          </Button>
        }
      />

      <div className="max-w-sm">
        <Input
          placeholder="Search clients (name, email, notes)..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <DataTable
        data={clients}
        columns={columns}
        onRowClick={(client) => navigate(`/clients/${client.id}`)}
        emptyMessage={isLoading ? "Loading..." : "No clients found."}
        isLoading={isLoading}
      />
    </div>
  );
}

export default ClientsPage;
