// src/services/workoutPlans.service.ts
import api from "@/services/api";

const BASE = "/v2/workout-plans";
const EMPTY_GUID = "00000000-0000-0000-0000-000000000000";

function normalize(doc: any): WorkoutPlanView {
  const isSystem = doc.coachId === EMPTY_GUID;

  return {
    id: doc.id,
    name: doc.meta?.name ?? "",
    description: doc.meta?.description,
    durationWeeks: doc.meta?.durationWeeks ?? 0,
    days: doc.days ?? [],

    isPublished: doc.meta?.isPublished ?? false,

    state: doc.assignedToClient
      ? "assigned"
      : doc.meta?.isPublished
      ? "template"
      : "draft",

    owner: isSystem ? "admin" : "coach",
    coachId: doc.coachId,

    createdAt: doc.createdAt,
    updatedAt: doc.updatedAt,
  };
}

export const workoutPlansService = {
  /* -------- Core -------- */

  async list(): Promise<WorkoutPlanView[]> {
    const raw = await api.get<any[]>(BASE);
    return raw.map(normalize);
  },

  async get(id: string): Promise<WorkoutPlanView> {
    const raw = await api.get<any>(`${BASE}/${id}`);
    return normalize(raw);
  },

  async createDraft(payload: any): Promise<{ id: string }> {
    return api.post(`${BASE}`, payload);
  },

  async updateDraft(id: string, payload: any) {
    return api.put(`${BASE}/${id}`, payload);
  },

  async deleteDraft(id: string) {
    return api.delete(`${BASE}/${id}`);
  },

  /* -------- Coach -------- */

  async listCoachDrafts() {
    const all = await this.list();
    return all.filter(p => p.state === "draft" && p.owner === "coach");
  },

  async listCoachTemplates() {
    const all = await this.list();
    return all.filter(p => p.state === "template" && p.owner === "coach");
  },

  async listCoachAssigned() {
    return api.get(`${BASE}/assigned`);
  },

  async assignToClient(planId: string, clientId: string) {
    return api.post(`${BASE}/${planId}/assign`, { clientId });
  },

  /* ----------------------------------
   COACH · ASSIGNED PLANS
---------------------------------- */
async listAssignedForCoach(): Promise<ClientWorkoutPlan[]> {
  return apiService.get<ClientWorkoutPlan[]>(
    "/v2/workout-plans/assigned"
  );
},


  /* -------- Client -------- */

  async listClientAssigned() {
    return api.get(`${BASE}/my`);
  },

  async listClientDrafts() {
    const all = await this.list();
    return all.filter(p => p.state === "draft" && p.owner === "client");
  },

  async listPublicTemplates() {
    const all = await this.list();
    return all.filter(p => p.state === "template" && p.owner === "admin");
  },
};
