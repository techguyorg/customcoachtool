using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models;

public class UserLastActivity
{
    [Key]
    public Guid UserId { get; set; }

    [Required]
    [MaxLength(50)]
    public string Domain { get; set; } = null!; // "workout-plan", later "diet-plan"

    [Required]
    public Guid EntityId { get; set; }

    [Required]
    [MaxLength(200)]
    public string EntityName { get; set; } = null!;

    [Required]
    [MaxLength(20)]
    public string Action { get; set; } = null!; // created | edited | duplicated | assigned

    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
}
