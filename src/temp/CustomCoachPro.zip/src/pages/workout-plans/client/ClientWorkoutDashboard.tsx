import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import workoutPlanService from "@/services/workoutPlanService";
import type { ClientWorkoutPlan } from "@/types";

export default function ClientWorkoutDashboard() {
  const { data = [], isLoading } = useQuery({
    queryKey: ["client-assigned-plans"],
    queryFn: () => workoutPlanService.listForClient(),
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="text-2xl font-semibold">My workouts</h1>

      {isLoading && <Card className="p-6">Loading…</Card>}

      {!isLoading && data.length === 0 && (
        <Card className="p-6 text-muted-foreground">
          No active workout plans yet.
        </Card>
      )}

      <div className="grid gap-4">
        {data.map((plan) => (
          <Card key={plan.id} className="p-4">
            <div className="font-medium">
              {plan.definition.meta.name}
            </div>
            <div className="text-sm text-muted-foreground">
              {plan.definition.meta.durationWeeks} weeks
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
