using System.ComponentModel.DataAnnotations;
using FitCoachPro.Api.Models.Library;

namespace FitCoachPro.Api.Models.Templates;

public class WorkoutTemplateExercise
{
    public Guid Id { get; set; } = Guid.NewGuid();

    public Guid WorkoutTemplateDayId { get; set; }
    public WorkoutTemplateDay WorkoutTemplateDay { get; set; } = null!;

    public Guid ExerciseLibraryItemId { get; set; }
    public ExerciseLibraryItem Exercise { get; set; } = null!;

    public int SortOrder { get; set; } = 0;

    [MaxLength(64)]
    public string? Sets { get; set; }     // "3-4"
    [MaxLength(64)]
    public string? Reps { get; set; }     // "8-12"
    [MaxLength(64)]
    public string? RestSeconds { get; set; } // "60-90"

    [MaxLength(512)]
    public string? Notes { get; set; } // cues, tempo, etc.
}
