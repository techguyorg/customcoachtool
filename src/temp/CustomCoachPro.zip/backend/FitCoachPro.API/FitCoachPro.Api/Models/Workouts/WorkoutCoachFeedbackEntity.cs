using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models.Workouts;

public class WorkoutCoachFeedbackEntity
{
    [Key]
    public Guid Id { get; set; }

    // Ownership
    public Guid CoachId { get; set; }
    public Guid ClientId { get; set; }

    // Target (one of these will be set)
    public Guid? WorkoutSessionId { get; set; }
    public Guid? WorkoutExerciseLogId { get; set; }

    // Content
    [Required]
    public string Comment { get; set; } = "";

    // Metadata
    public DateTime CreatedAt { get; set; }
}
