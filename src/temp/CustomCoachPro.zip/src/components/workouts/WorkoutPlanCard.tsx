import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Props {
  plan: {
    id: string;
    name: string;
    goal?: string;
    status?: string;
  };
  onView: () => void;
  onEdit?: () => void;
  onUse?: () => void;
  onAssign?: () => void;
}

export function WorkoutPlanCard({
  plan,
  onView,
  onEdit,
  onUse,
  onAssign,
}: Props) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{plan.name}</CardTitle>
      </CardHeader>

      <CardContent className="space-y-2">
        {plan.goal && (
          <p className="text-sm text-muted-foreground">
            Goal: {plan.goal}
          </p>
        )}

        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={onView}>
            View
          </Button>

          {onEdit && (
            <Button size="sm" onClick={onEdit}>
              Edit
            </Button>
          )}

          {onUse && (
            <Button size="sm" variant="secondary" onClick={onUse}>
              Use
            </Button>
          )}

          {onAssign && (
            <Button size="sm" variant="ghost" onClick={onAssign}>
              Assign
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
