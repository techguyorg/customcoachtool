import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

export default function WorkoutPlansEntry() {
  const { user } = useAuth();

  if (!user) return null;

  if (user.role === "admin") {
    return <Navigate to="/workout-plans/admin/templates" replace />;
  }

  if (user.role === "coach") {
    return <Navigate to="/workout-plans/coach" replace />;
  }

  return <Navigate to="/workout-plans/client" replace />;
}
