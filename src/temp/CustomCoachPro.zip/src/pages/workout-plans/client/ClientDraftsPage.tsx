import { useQuery } from "@tanstack/react-query";
import workoutPlanService from "@/services/workoutPlanService";
import { Card } from "@/components/ui/card";

export default function ClientDraftsPage() {
  const { data = [] } = useQuery({
    queryKey: ["client-drafts"],
    queryFn: () => workoutPlanService.listClientDrafts(),
  });

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">My drafts</h1>

      {data.map((plan) => (
        <Card key={plan.id} className="p-4">
          <div className="font-medium">{plan.name}</div>
          <div className="text-sm text-muted-foreground">
            Not assigned yet
          </div>
        </Card>
      ))}
    </div>
  );
}
