import { ArrowLeft } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import WorkoutPlanForm from "./WorkoutPlanForm";
import workoutPlanService, {
  type UpdateWorkoutPlanPayload,
} from "@/services/workoutPlanService";

const EMPTY_GUID = "00000000-0000-0000-0000-000000000000";

export function EditWorkoutPlanPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  if (!id) return null;

  const {
    data: plan,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["workout-plan", id],
    queryFn: () => workoutPlanService.get(id),
  });

  const updateMutation = useMutation({
    mutationFn: (payload: UpdateWorkoutPlanPayload) =>
      workoutPlanService.update(id, payload),
    onSuccess: () => {
      toast({ title: "Workout plan updated" });
      queryClient.invalidateQueries({ queryKey: ["workout-plans"] });
      queryClient.invalidateQueries({ queryKey: ["workout-plan", id] });
      navigate("/workout-plans");
    },
    onError: (error) => {
      toast({
        title: "Unable to update plan",
        description:
          error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => workoutPlanService.remove(id),
    onSuccess: () => {
      toast({ title: "Workout plan deleted" });
      queryClient.invalidateQueries({ queryKey: ["workout-plans"] });
      navigate("/workout-plans");
    },
    onError: (error) => {
      toast({
        title: "Unable to delete plan",
        description:
          error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    },
  });

  const isSystemPlan =
    plan?.coachId === EMPTY_GUID;

  return (
    <div className="space-y-6 animate-fade-in max-w-5xl mx-auto">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/workout-plans")}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>

        <Card className="px-4 py-2 border-dashed text-sm text-muted-foreground">
          Update plan details or tweak the day layout.
        </Card>
      </div>

      {isLoading && (
        <div className="h-10 w-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
      )}

      {isError && (
        <div className="text-center text-sm text-destructive">
          Unable to load workout plan. Please go back and try again.
        </div>
      )}

      {plan && (
        <>
          <WorkoutPlanForm
            initialData={plan}
            title="Edit workout plan"
            description="Adjust workouts and details without losing existing structure."
            submitLabel="Save changes"
            isSubmitting={updateMutation.isPending}
            onCancel={() => navigate("/workout-plans")}
            onSubmit={(payload) =>
              updateMutation.mutateAsync(payload)
            }
          />

          {!isSystemPlan && (
            <div className="flex justify-between items-center mt-6">
              <Button
                variant="ghost"
                className="text-destructive hover:bg-destructive/10"
                disabled={deleteMutation.isPending}
                onClick={() => {
                  if (
                    !confirm(
                      "This will permanently delete the workout plan. This cannot be undone."
                    )
                  )
                    return;

                  deleteMutation.mutate();
                }}
              >
                {deleteMutation.isPending
                  ? "Deleting..."
                  : "Delete plan"}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default EditWorkoutPlanPage;
