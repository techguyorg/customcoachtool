import { useQuery } from "@tanstack/react-query";
import { CalendarDays, User } from "lucide-react";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import workoutPlanService from "@/services/workoutPlanService";
import type { ClientWorkoutPlan } from "@/types";

/* --------------------------------------------------
   COACH · ASSIGNED WORKOUT PLANS
-------------------------------------------------- */

export default function CoachAssignedPage() {
  const { data = [], isLoading } = useQuery({
    queryKey: ["assigned-workout-plans"],
    queryFn: () => workoutPlanService.listAssignedForCoach(),
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold">
          Assigned workout plans
        </h1>
        <p className="text-sm text-muted-foreground">
          Plans currently active for your clients.
        </p>
      </div>

      {isLoading && (
        <Card className="p-6 text-sm text-muted-foreground">
          Loading assigned plans…
        </Card>
      )}

      {!isLoading && data.length === 0 && (
        <Card className="p-6 text-sm text-muted-foreground">
          No workout plans assigned yet.
        </Card>
      )}

      <div className="grid gap-4">
        {data.map((assigned) => (
          <AssignedPlanRow
            key={assigned.id}
            plan={assigned}
          />
        ))}
      </div>
    </div>
  );
}

/* --------------------------------------------------
   Assigned Row
-------------------------------------------------- */

function AssignedPlanRow({
  plan,
}: {
  plan: ClientWorkoutPlan;
}) {
  return (
    <Card className="p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="font-medium">
          {plan.definition.meta.name}
        </div>

        <Badge variant={plan.isActive ? "default" : "secondary"}>
          {plan.isActive ? "Active" : "Inactive"}
        </Badge>
      </div>

      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
        <span className="flex items-center gap-1">
          <User className="h-4 w-4" />
          Client ID: {plan.clientId}
        </span>

        <span className="flex items-center gap-1">
          <CalendarDays className="h-4 w-4" />
          Starts {new Date(plan.startsOn).toLocaleDateString()}
        </span>
      </div>
    </Card>
  );
}
