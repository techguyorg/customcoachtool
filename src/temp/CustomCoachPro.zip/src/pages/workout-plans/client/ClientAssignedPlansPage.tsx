import { useQuery } from "@tanstack/react-query";
import workoutPlanService from "@/services/workoutPlanService";
import { Card } from "@/components/ui/card";

export default function ClientAssignedPlansPage() {
  const { data = [] } = useQuery({
    queryKey: ["client-assigned"],
    queryFn: () => workoutPlanService.listForClient(),
  });

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">
        Active programs
      </h1>

      {data.map((p) => (
        <Card key={p.id} className="p-4">
          <div className="font-medium">
            {p.definition.meta.name}
          </div>
          <div className="text-sm text-muted-foreground">
            Starts {new Date(p.startsOn).toLocaleDateString()}
          </div>
        </Card>
      ))}
    </div>
  );
}
