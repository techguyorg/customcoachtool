import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export type WorkoutPlanFilterState = {
  search: string;
  minDays?: number;
  maxDays?: number;
};

type Props = {
  filters: WorkoutPlanFilterState;
  onChange: (next: WorkoutPlanFilterState) => void;
};

const DEFAULT_FILTERS: WorkoutPlanFilterState = {
  search: "",
};

export default function WorkoutPlanFilters({ filters, onChange }: Props) {
  const hasActiveFilters =
    filters.search.trim() !== "" ||
    filters.minDays !== undefined ||
    filters.maxDays !== undefined;

  return (
    <Card className="bg-muted/30 border-muted">
      <CardContent className="pt-0 pb-0">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-[2fr_1fr_1fr_auto_auto] items-end">
          {/* Search */}
          <div className="space-y-0.5">
            <Label className="text-xs text-muted-foreground">
              Search plans
            </Label>
            <Input
              placeholder="Search by plan name"
              value={filters.search}
              onChange={(e) =>
                onChange({ ...filters, search: e.target.value })
              }
            />
          </div>

          {/* Min days */}
          <div className="space-y-0.5">
            <Label className="text-xs text-muted-foreground">
              Min days
            </Label>
            <Input
              type="number"
              placeholder="e.g. 3"
              value={filters.minDays ?? ""}
              onChange={(e) =>
                onChange({
                  ...filters,
                  minDays: e.target.value
                    ? Number(e.target.value)
                    : undefined,
                })
              }
            />
          </div>

          {/* Max days */}
          <div className="space-y-0.5">
            <Label className="text-xs text-muted-foreground">
              Max days
            </Label>
            <Input
              type="number"
              placeholder="e.g. 6"
              value={filters.maxDays ?? ""}
              onChange={(e) =>
                onChange({
                  ...filters,
                  maxDays: e.target.value
                    ? Number(e.target.value)
                    : undefined,
                })
              }
            />
          </div>

          {/* Clear */}
          <div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onChange(DEFAULT_FILTERS)}
            >
              Clear
            </Button>
          </div>

          {/* Apply (intentional but passive) */}
          <div>
            <Button size="sm">Apply</Button>
          </div>
        </div>

        {/* Helper text */}
        <div className="mt-1 text-xs text-muted-foreground">
          {hasActiveFilters
            ? "Filters are applied automatically as you type."
            : "Showing all available workout plans."}
        </div>
      </CardContent>
    </Card>
  );
}
