import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Copy, Users, Pencil } from "lucide-react";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import workoutPlanService from "@/services/workoutPlanService";
import type { WorkoutPlan } from "@/types";

export default function CoachTemplatesPage() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["workout-plans"],
    queryFn: () => workoutPlanService.list(),
  });

  if (!user) return null;

  const templates = plans
    .filter(
      (p) => p.coachId === user.id && p.isPublished
    )
    .sort(
      (a, b) =>
        new Date(b.updatedAt).getTime() -
        new Date(a.updatedAt).getTime()
    );

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold">
          Workout templates
        </h1>
        <p className="text-sm text-muted-foreground">
          Published plans ready to assign or reuse.
        </p>
      </div>

      {isLoading && (
        <Card className="p-6 text-sm text-muted-foreground">
          Loading templates…
        </Card>
      )}

      {!isLoading && templates.length === 0 && (
        <Card className="p-6 text-sm text-muted-foreground">
          You haven’t published any plans yet.
        </Card>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {templates.map((plan) => (
          <TemplateCard
            key={plan.id}
            plan={plan}
            onEdit={() =>
              navigate(`/workout-plans/${plan.id}/edit`)
            }
            onAssign={() =>
              navigate(`/clients?assignPlan=${plan.id}`)
            }
            onDuplicate={async () => {
              const created =
                await workoutPlanService.duplicate(plan.id);
              navigate(`/workout-plans/${created.id}/edit`);
            }}
          />
        ))}
      </div>
    </div>
  );
}

/* -----------------------------
   Template Card
------------------------------ */

function TemplateCard({
  plan,
  onEdit,
  onAssign,
  onDuplicate,
}: {
  plan: WorkoutPlan;
  onEdit: () => void;
  onAssign: () => void;
  onDuplicate: () => void;
}) {
  return (
    <Card className="p-4 space-y-3 hover:shadow-md transition">
      <div className="font-medium">{plan.name}</div>

      <div className="text-xs text-muted-foreground">
        {plan.durationWeeks} weeks · {plan.days.length} days
      </div>

      <div className="flex gap-2 pt-2">
        <Button size="sm" onClick={onAssign}>
          <Users className="h-4 w-4 mr-1" />
          Assign
        </Button>

        <Button
          size="sm"
          variant="outline"
          onClick={onDuplicate}
        >
          <Copy className="h-4 w-4 mr-1" />
          Duplicate
        </Button>

        <Button
          size="sm"
          variant="ghost"
          className="ml-auto"
          onClick={onEdit}
        >
          <Pencil className="h-4 w-4" />
        </Button>
      </div>
    </Card>
  );
}
