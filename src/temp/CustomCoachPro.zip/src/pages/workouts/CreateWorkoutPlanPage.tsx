import { ArrowLeft, PlusCircle } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

import WorkoutPlanForm from "./WorkoutPlanForm";
import workoutPlanService, {
  type WorkoutPlanPayload,
} from "@/services/workoutPlanService";

/* -----------------------------------------------------
   CREATE WORKOUT PLAN — FROM SCRATCH ONLY
----------------------------------------------------- */
export function CreateWorkoutPlanPage() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const createMutation = useMutation({
    mutationFn: (payload: WorkoutPlanPayload) =>
      workoutPlanService.create(payload),
    onSuccess: ({ id }) => {
      toast({ title: "Workout plan created" });
      navigate(`/workout-plans/${id}/edit`);
    },

    onError: (error) => {
      toast({
        title: "Unable to create workout plan",
        description:
          error instanceof Error
            ? error.message
            : "Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      {/* PAGE HEADER */}
      <div className="space-y-4">
        <Button
          variant="ghost"
          size="sm"
          className="px-0 text-muted-foreground"
          onClick={() => navigate("/workout-plans")}
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Workout Plans
        </Button>

        <div className="space-y-1">
          <h1 className="text-2xl font-semibold flex items-center gap-2">
            <PlusCircle className="h-6 w-6 text-primary" />
            Create a new workout plan
          </h1>
          <p className="text-sm text-muted-foreground max-w-2xl">
            Start from a clean slate and design a workout program tailored
            to your client’s goals. You can assign this plan after creation.
          </p>
        </div>
      </div>

      {/* CREATION FORM */}
      <Card>
        <CardHeader>
          <CardTitle>Workout plan details</CardTitle>
          <CardDescription>
            Define the structure, schedule, and progression of the plan.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <WorkoutPlanForm
            title="Create workout plan"
            description="Build a new workout program from scratch."
            submitLabel="Create workout plan"
            isSubmitting={createMutation.isPending}
            onCancel={() => navigate("/workout-plans")}
            onSubmit={(payload) =>
              createMutation.mutateAsync(payload)
            }
          />
        </CardContent>
      </Card>
    </div>
  );
}

export default CreateWorkoutPlanPage;
