import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  Plus,
  Layers,
  LayoutDashboard,
  Dumbbell,
  Sparkles,
  ArrowRight,
  Edit3,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { PageHeader } from "@/components/shared/PageHeader";
import { Badge } from "@/components/ui/badge";
import workoutService from "@/services/workoutService";

/* -----------------------------------------------------
   UI CONTRACT (DO NOT BREAK)
   -----------------------------------------------------
   - This page is a DECISION HUB, not a management screen
   - Left rail = Coach workspace tools
   - Main canvas = How to start
   - No plan lists, filters, or analytics here
----------------------------------------------------- */

export function WorkoutPlansPage() {
  const navigate = useNavigate();

  // SaaS-backed "Continue where you left off"
  const { data: lastActivity } = useQuery({
    queryKey: ["last-workout-plan-activity"],
    queryFn: () => workoutService.getLastWorkoutPlanActivity(),
  });

  return (
    <div className="space-y-8 animate-fade-in">
      {/* PAGE HEADER */}
      <PageHeader
        title="Workout Programs"
        description="Build, reuse, or start from proven programs for your clients"
        actions={
          <Button onClick={() => navigate("/workout-plans/new")}>
            <Plus className="h-4 w-4 mr-2" />
            Create Plan
          </Button>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6">
        {/* LEFT RAIL — COACH WORKSPACE */}
        <Card className="h-fit">
          <CardHeader className="space-y-1">
            <CardTitle className="text-sm flex items-center gap-2">
              <LayoutDashboard className="h-4 w-4" />
              Coach Workspace
            </CardTitle>
            <CardDescription className="text-xs">
              Your planning and training tools
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-5">
            <div className="space-y-2">
              <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                My Workspace
              </div>

              <Button
                variant="secondary"
                className="w-full justify-start"
                onClick={() => navigate("/workout-plans/new")}
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Plan
              </Button>

              <Button
                variant="secondary"
                className="w-full justify-start"
                onClick={() => navigate("/exercise-catalog")}
              >
                <Dumbbell className="h-4 w-4 mr-2" />
                Exercise Library
              </Button>
            </div>

            <div className="pt-3 border-t">
              <Button
                variant="ghost"
                className="w-full justify-start text-sm"
                onClick={() => navigate("/workout-plans/reuse")}
              >
                View all my workout plans
                <ArrowRight className="h-4 w-4 ml-auto" />
              </Button>
            </div>

            <div className="space-y-2 pt-3 border-t">
              <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Insights
              </div>

              <Button
                variant="ghost"
                className="w-full justify-start opacity-50 cursor-not-allowed"
              >
                <Sparkles className="h-4 w-4 mr-2" />
                Plan Performance
              </Button>

              <Button
                variant="ghost"
                className="w-full justify-start opacity-50 cursor-not-allowed"
              >
                <Sparkles className="h-4 w-4 mr-2" />
                Client Adherence
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* MAIN CANVAS — DECISION HUB */}
        <Card>
          <CardContent className="pt-10 pb-12">
            <div className="max-w-3xl mx-auto space-y-10">
              {/* CONTINUE WHERE YOU LEFT OFF */}
              {lastActivity && (
                <Card className="border-dashed">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="space-y-1">
                      <div className="text-sm font-medium">
                        Continue where you left off
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {lastActivity.planName}
                      </div>
                    </div>

                    <Button
                      size="sm"
                      onClick={() =>
                        navigate(
                          `/workout-plans/${lastActivity.planId}/edit`
                        )
                      }
                    >
                      Continue
                    </Button>
                  </CardContent>
                </Card>
              )}

              {/* DECISION CONTEXT */}
              <div className="text-center space-y-2">
                <h2 className="text-xl font-semibold">
                  Start building a workout program
                </h2>
                <p className="text-sm text-muted-foreground">
                  Choose a starting point. You can always customize later.
                </p>
              </div>

              {/* DECISION CARDS — FINAL */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* SYSTEM TEMPLATES — PRIMARY */}
                <Card
                  className="cursor-pointer hover:bg-muted/30 transition relative ring-2 ring-primary/30"
                  onClick={() => navigate("/workout-templates")}
                >
                  <CardContent className="p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <Layers className="h-6 w-6 text-primary" />
                      <Badge variant="secondary">Recommended</Badge>
                    </div>

                    <div className="space-y-1">
                      <div className="font-medium">
                        Start from proven templates
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Admin-curated programs for common goals
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* CONTINUE WORKSPACE */}
                <Card
                  className="cursor-pointer hover:bg-muted/30 transition"
                  onClick={() => navigate("/workout-plans/reuse")}
                >
                  <CardContent className="p-6 space-y-3">
                    <Edit3 className="h-6 w-6 text-primary" />
                    <div className="space-y-1">
                      <div className="font-medium">
                        Continue my work
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Pick up where you left off
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* CREATE FROM SCRATCH */}
                <Card
                  className="cursor-pointer hover:bg-muted/30 transition"
                  onClick={() => navigate("/workout-plans/new")}
                >
                  <CardContent className="p-6 space-y-3">
                    <Plus className="h-6 w-6 text-primary" />
                    <div className="space-y-1">
                      <div className="font-medium">
                        Create from scratch
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Full control for advanced needs
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default WorkoutPlansPage;
