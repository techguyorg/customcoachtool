import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Dumbbell } from "lucide-react";

import workoutPlanService from "@/services/workoutPlanService";
import WorkoutPlanCard from "../shared/WorkoutPlanCard";
import { EmptyState } from "@/components/shared/EmptyState";

export default function ClientExploreTemplatesPage() {
  const navigate = useNavigate();

  const { data, isLoading } = useQuery({
    queryKey: ["client-templates"],
    queryFn: () => workoutPlanService.listTemplates(),
  });

  const templates = data?.items ?? [];

  if (!isLoading && templates.length === 0) {
    return (
      <EmptyState
        icon={Dumbbell}
        title="No programs available"
        description="No published workout programs found."
      />
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Explore workout programs</h1>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {templates.map((plan) => (
          <WorkoutPlanCard
            key={plan.id}
            plan={plan}
            onView={() => navigate(`/workout-plans/${plan.id}`)}
            primaryAction={{
              label: "Use program",
              onClick: async () => {
                const { id } = await workoutPlanService.duplicate(plan.id);
                navigate(`/workout-plans/${id}/edit`);
              },
            }}
          />
        ))}
      </div>
    </div>
  );
}
