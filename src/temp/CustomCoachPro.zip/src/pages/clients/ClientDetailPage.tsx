import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Mail,
  Calendar,
  Target,
  Scale,
  TrendingDown,
  Edit,
  Ruler,
  Dumbbell,
  Utensils,
  Activity,
  ClipboardCheck,
  Eye,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import coachService from "@/services/coachService";
import workoutPlanService from "@/services/workoutPlanService";
import dietPlanService from "@/services/dietPlanService";
import checkInService from "@/services/checkInService";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

type UnitSystem = "imperial" | "metric";

const INCH_TO_CM = 2.54;
const LB_TO_KG = 0.45359237;

const round1 = (n: number) => Math.round(n * 10) / 10;
const round0 = (n: number) => Math.round(n);

const safeNumber = (v: unknown): number | undefined =>
  typeof v === "number" && !Number.isNaN(v) ? v : undefined;

const convertWeight = (value: number | undefined, from: UnitSystem, to: UnitSystem) => {
  if (value === undefined || Number.isNaN(value)) return 0;
  if (from === to) return value;
  return from === "imperial" ? value * LB_TO_KG : value / LB_TO_KG;
};

// Stored lengths are treated as CM.
const convertLength = (valueCm: number | undefined, to: UnitSystem) => {
  if (valueCm === undefined || Number.isNaN(valueCm)) return undefined;
  return to === "imperial" ? valueCm / INCH_TO_CM : valueCm;
};

const formatSigned = (value: number, unit: string, decimals = 1) => {
  const abs = Math.abs(value);
  const rounded = decimals === 0 ? round0(abs) : round1(abs);
  const sign = value > 0 ? "+" : value < 0 ? "−" : "";
  return `${sign}${rounded} ${unit}`;
};

export function ClientDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [unitSystem, setUnitSystem] = useState<UnitSystem>("imperial");

  const [selectedWorkoutPlan, setSelectedWorkoutPlan] = useState("");
  const [workoutStartDate, setWorkoutStartDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [workoutDuration, setWorkoutDuration] = useState("");

  const [selectedDietPlan, setSelectedDietPlan] = useState("");
  const [dietStartDate, setDietStartDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [dietDuration, setDietDuration] = useState("");

  // ✅ Notes state
  const [noteDraft, setNoteDraft] = useState("");

  // ✅ Notes edit state (added)
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editingNoteContent, setEditingNoteContent] = useState("");

  const clientId = id ?? "";

  const { data, isLoading, error } = useQuery({
    queryKey: ["coach", "client", clientId],
    queryFn: () => coachService.getClient(clientId),
    enabled: !!clientId,
  });

  const { data: workoutPlans = [] } = useQuery({
    queryKey: ["workout-plans"],
    queryFn: () => workoutPlanService.list(),
  });

  const { data: dietPlans = [] } = useQuery({
    queryKey: ["diet-plans"],
    queryFn: () => dietPlanService.list(),
  });

  const { data: workoutAssignments = [] } = useQuery({
    queryKey: ["client", clientId, "workout-assignments"],
    queryFn: () => workoutPlanService.listForClient(clientId),
    enabled: !!clientId,
  });

  const { data: dietAssignments = [] } = useQuery({
    queryKey: ["client", clientId, "diet-assignments"],
    queryFn: () => dietPlanService.listForClient(clientId),
    enabled: !!clientId,
  });

  // Weight check-ins drive the “latest measurement snapshot”
  const { data: weightCheckIns = [] } = useQuery({
    queryKey: ["client", clientId, "checkins", "weight-history"],
    queryFn: () =>
      checkInService.getCheckIns({
        clientId,
        type: "weight",
        sortBy: "submittedAt",
        sortDirection: "asc",
      }),
    enabled: !!clientId,
  });

  // Latest activity (any type)
  const { data: latestAnyCheckIn = null } = useQuery({
    queryKey: ["client", clientId, "checkins", "latest-any"],
    queryFn: async () => {
      const list = await checkInService.getCheckIns({
        clientId,
        sortBy: "submittedAt",
        sortDirection: "desc",
      });
      return list?.[0] ?? null;
    },
    enabled: !!clientId,
  });

  // ✅ Notes (Coach-only)
  const {
    data: clientNotes = [],
    isLoading: isLoadingNotes,
    error: notesError,
  } = useQuery({
    queryKey: ["client", clientId, "notes"],
    queryFn: () => coachService.getClientNotes(clientId),
    enabled: !!clientId,
  });

  const createNoteMutation = useMutation({
    mutationFn: () => coachService.createClientNote(clientId, { content: noteDraft.trim() }),
    onSuccess: () => {
      setNoteDraft("");
      toast({ title: "Note saved" });
      queryClient.invalidateQueries({ queryKey: ["client", clientId, "notes"] });
    },
    onError: (err) => {
      toast({
        title: "Unable to save note",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: (noteId: string) => coachService.deleteClientNote(clientId, noteId),
    onSuccess: () => {
      toast({ title: "Note deleted" });
      queryClient.invalidateQueries({ queryKey: ["client", clientId, "notes"] });
    },
    onError: (err) => {
      toast({
        title: "Unable to delete note",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    },
  });

  // ✅ Update note (added)
  const updateNoteMutation = useMutation({
    mutationFn: (payload: { noteId: string; content: string }) =>
      coachService.updateClientNote(clientId, payload.noteId, { content: payload.content }),
    onSuccess: () => {
      toast({ title: "Note updated" });
      setEditingNoteId(null);
      setEditingNoteContent("");
      queryClient.invalidateQueries({ queryKey: ["client", clientId, "notes"] });
    },
    onError: (err) => {
      toast({
        title: "Unable to update note",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    },
  });

  const assignWorkoutMutation = useMutation({
    mutationFn: () =>
      workoutPlanService.assign({
        clientId,
        workoutPlanId: selectedWorkoutPlan,
        startDate: new Date(workoutStartDate).toISOString(),
        durationDays: workoutDuration ? Number(workoutDuration) : undefined,
      }),
    onSuccess: () => {
      toast({ title: "Workout plan assigned" });
      queryClient.invalidateQueries({ queryKey: ["client", clientId, "workout-assignments"] });
    },
    onError: (err) => {
      toast({
        title: "Unable to assign workout plan",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    },
  });

  const assignDietMutation = useMutation({
    mutationFn: () =>
      dietPlanService.assign({
        clientId,
        dietPlanId: selectedDietPlan,
        startDate: new Date(dietStartDate).toISOString(),
        durationDays: dietDuration ? Number(dietDuration) : undefined,
      }),
    onSuccess: () => {
      toast({ title: "Diet plan assigned" });
      queryClient.invalidateQueries({ queryKey: ["client", clientId, "diet-assignments"] });
    },
    onError: (err) => {
      toast({
        title: "Unable to assign diet plan",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (data?.profile?.preferredUnitSystem === "metric") {
      setUnitSystem("metric");
    }
  }, [data?.profile?.preferredUnitSystem]);

  const weightUnit = useMemo(() => (unitSystem === "imperial" ? "lbs" : "kg"), [unitSystem]);
  const lengthUnit = useMemo(() => (unitSystem === "imperial" ? "in" : "cm"), [unitSystem]);

  if (isLoading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="space-y-3">
        <h1 className="text-xl font-bold">Client not found</h1>
        <p className="text-muted-foreground">{error instanceof Error ? error.message : "Unable to load client."}</p>
        <Button variant="outline" onClick={() => navigate("/clients")}>
          Back to Clients
        </Button>
      </div>
    );
  }

  const profile = data.profile;
  const displayName = profile.displayName || data.email;

  const storedWeightUnit = (profile.preferredUnitSystem as UnitSystem | undefined) ?? "imperial";

  const firstWeightCI = weightCheckIns?.[0];
  const lastWeightCI = weightCheckIns?.[weightCheckIns.length - 1];
  const prevWeightCI = weightCheckIns.length >= 2 ? weightCheckIns[weightCheckIns.length - 2] : undefined;

  const currentWeightStored = safeNumber(lastWeightCI?.data?.weight) ?? safeNumber(profile.currentWeight) ?? undefined;
  const startWeightStored =
    safeNumber(firstWeightCI?.data?.weight) ?? safeNumber(profile.startWeight) ?? safeNumber(profile.currentWeight) ?? undefined;
  const targetWeightStored = safeNumber(profile.targetWeight) ?? undefined;

  const currentWeight = currentWeightStored ? convertWeight(currentWeightStored, storedWeightUnit, unitSystem) : 0;
  const startWeight = startWeightStored ? convertWeight(startWeightStored, storedWeightUnit, unitSystem) : 0;
  const targetWeight = targetWeightStored ? convertWeight(targetWeightStored, storedWeightUnit, unitSystem) : 0;

  // Latest check-in measurements (treated as CM for circumference fields)
  const latestBodyFat = safeNumber(lastWeightCI?.data?.bodyFat);
  const latestWaistCm = safeNumber(lastWeightCI?.data?.waist);
  const latestChestCm = safeNumber(lastWeightCI?.data?.chest);
  const latestArmsCm = safeNumber(lastWeightCI?.data?.arms);
  const latestThighsCm = safeNumber(lastWeightCI?.data?.thighs);

  const firstWaistCm = safeNumber(firstWeightCI?.data?.waist);
  const prevWaistCm = safeNumber(prevWeightCI?.data?.waist);
  const prevWeightStored = safeNumber(prevWeightCI?.data?.weight);

  const latestWaist = convertLength(latestWaistCm, unitSystem);
  const latestChest = convertLength(latestChestCm, unitSystem);
  const latestArms = convertLength(latestArmsCm, unitSystem);
  const latestThighs = convertLength(latestThighsCm, unitSystem);

  const waistStart = convertLength(firstWaistCm, unitSystem);

  const weightDelta = (() => {
    if (!currentWeightStored || !prevWeightStored) return undefined;
    const curr = convertWeight(currentWeightStored, storedWeightUnit, unitSystem);
    const prev = convertWeight(prevWeightStored, storedWeightUnit, unitSystem);
    return curr - prev;
  })();

  const waistDelta = (() => {
    if (latestWaistCm === undefined || prevWaistCm === undefined) return undefined;
    const curr = convertLength(latestWaistCm, unitSystem);
    const prev = convertLength(prevWaistCm, unitSystem);
    if (curr === undefined || prev === undefined) return undefined;
    return curr - prev;
  })();

  // Since start snapshot (first weight check-in if present)
  const weightChangeSinceStart = (() => {
    if (!currentWeightStored || !startWeightStored) return undefined;
    const curr = convertWeight(currentWeightStored, storedWeightUnit, unitSystem);
    const start = convertWeight(startWeightStored, storedWeightUnit, unitSystem);
    return curr - start;
  })();

  const waistChangeSinceStart = (() => {
    if (latestWaist === undefined || waistStart === undefined) return undefined;
    return latestWaist - waistStart;
  })();

  const weightLost = Math.max(0, startWeight - currentWeight);
  const totalToLose = targetWeightStored ? Math.max(0, startWeight - targetWeight) : 0;
  const progressPercentage = targetWeightStored && totalToLose > 0 ? Math.round((weightLost / totalToLose) * 100) : 0;

  const activeWorkoutAssignment = workoutAssignments.find((a) => a.isActive) ?? workoutAssignments[0];
  const activeDietAssignment = dietAssignments.find((a) => a.isActive) ?? dietAssignments[0];

  const assignedWorkoutPlan =
    activeWorkoutAssignment?.workoutPlan || workoutPlans.find((plan) => plan.id === activeWorkoutAssignment?.workoutPlanId);

  const assignedDietPlan =
    activeDietAssignment?.dietPlan || dietPlans.find((plan) => plan.id === activeDietAssignment?.dietPlanId);

  const formatDate = (value?: string | null) => (value ? new Date(value).toLocaleDateString() : "Not set");
  const formatDateTime = (value?: string | null) => (value ? new Date(value).toLocaleString() : "—");

  const height = convertLength(profile.heightCm ?? undefined, unitSystem);
  const neck = convertLength(profile.neckCm ?? undefined, unitSystem);
  const arms = convertLength(profile.armsCm ?? undefined, unitSystem);
  const quads = convertLength(profile.quadsCm ?? undefined, unitSystem);
  const hips = convertLength(profile.hipsCm ?? undefined, unitSystem);

  const lastActivityLabel = latestAnyCheckIn
    ? `${latestAnyCheckIn.type} • ${formatDateTime(latestAnyCheckIn.submittedAt)}`
    : "No check-ins yet";

  const goalBanner = (() => {
    if (!targetWeightStored) {
      return {
        title: "Goal not set",
        subtitle: "Set a target weight to track progress.",
        progress: 0,
        meta: null as string | null,
      };
    }

    const remaining = Math.max(0, targetWeight - currentWeight);
    const remainingText = `${round1(remaining)} ${weightUnit} to goal`;
    const meta = `${round1(currentWeight)} ${weightUnit} now • ${remainingText}`;

    return {
      title: "Goal progress",
      subtitle: `${round1(startWeight)} → ${round1(targetWeight)} ${weightUnit}`,
      progress: progressPercentage,
      meta,
    };
  })();

  const totalWeightCheckIns = weightCheckIns.length;

  const daysSinceLastWeight = (() => {
    if (!lastWeightCI?.submittedAt) return undefined;
    const ms = Date.now() - new Date(lastWeightCI.submittedAt).getTime();
    const days = ms / (1000 * 60 * 60 * 24);
    return Math.max(0, Math.floor(days));
  })();

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate("/clients")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>

        <div className="flex-1 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Avatar className="h-14 w-14 border-2 border-primary/20">
              <AvatarFallback className="bg-primary/10 text-primary text-xl">
                {displayName?.[0]?.toUpperCase() ?? "C"}
              </AvatarFallback>
            </Avatar>

            <div>
              <h1 className="text-2xl font-display font-bold">{displayName}</h1>
              <p className="text-muted-foreground">{data.email}</p>
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
                <Activity className="h-3.5 w-3.5" />
                {lastActivityLabel}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => navigate(`/clients/${clientId}/edit`)}>
              <Edit className="h-4 w-4 mr-2" />
              Edit Profile
            </Button>
          </div>
        </div>
      </div>

      {/* Units */}
      <div className="flex flex-wrap gap-2">
        <Button type="button" variant={unitSystem === "imperial" ? "default" : "outline"} onClick={() => setUnitSystem("imperial")}>
          Imperial (lbs/in)
        </Button>
        <Button type="button" variant={unitSystem === "metric" ? "default" : "outline"} onClick={() => setUnitSystem("metric")}>
          Metric (kg/cm)
        </Button>
      </div>

      {/* Snapshot (now includes Waist) */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="md:col-span-2">
          <CardContent className="p-4">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Scale className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Current Weight</p>
                  <p className="text-2xl font-bold">
                    {round1(currentWeight)} {weightUnit}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {lastWeightCI ? `Last logged: ${formatDateTime(lastWeightCI.submittedAt)}` : "No weight check-ins yet"}
                  </p>
                </div>
              </div>

              {weightDelta !== undefined ? (
                <Badge variant="outline" className="text-sm">
                  {formatSigned(weightDelta, weightUnit, 1)} since last
                </Badge>
              ) : (
                <Badge variant="outline" className="text-sm">
                  —
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-secondary/10">
                  <Ruler className="h-5 w-5 text-secondary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Waist</p>
                  <p className="text-xl font-bold">
                    {latestWaist !== undefined ? `${round1(latestWaist)} ${lengthUnit}` : "—"}
                  </p>
                  <p className="text-xs text-muted-foreground">Latest check-in</p>
                </div>
              </div>
              {waistDelta !== undefined ? (
                <Badge variant="outline" className="text-sm">
                  {formatSigned(waistDelta, lengthUnit, 1)}
                </Badge>
              ) : (
                <Badge variant="outline" className="text-sm">
                  —
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/10">
                <Target className="h-5 w-5 text-accent" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Target Weight</p>
                <p className="text-xl font-bold">{targetWeightStored ? `${round1(targetWeight)} ${weightUnit}` : "Not set"}</p>
                <p className="text-xs text-muted-foreground">From profile</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Compact Goal Banner */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-semibold">{goalBanner.title}</p>
                <p className="text-sm text-muted-foreground">{goalBanner.subtitle}</p>
                {goalBanner.meta && <p className="text-xs text-muted-foreground mt-1">{goalBanner.meta}</p>}
              </div>

              {!targetWeightStored ? (
                <Button variant="outline" size="sm" onClick={() => navigate(`/clients/${clientId}/edit`)}>
                  Set goal
                </Button>
              ) : null}
            </div>

            <div className="min-w-[220px]">
              <Progress value={goalBanner.progress} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1 text-right">{targetWeightStored ? `${goalBanner.progress}%` : "—"}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Coach-first summary */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Overview</CardTitle>
            <CardDescription>What changed + where they are now.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <div className="rounded-lg border p-3">
              <p className="text-sm font-medium text-foreground flex items-center gap-2">
                <TrendingDown className="h-4 w-4 text-muted-foreground" />
                Progress since start
              </p>
              <div className="mt-2 grid gap-1 text-sm text-muted-foreground">
                <p>
                  Weight:{" "}
                  {weightChangeSinceStart !== undefined ? (
                    <span className="font-medium text-foreground">{formatSigned(weightChangeSinceStart, weightUnit, 1)}</span>
                  ) : (
                    "—"
                  )}
                </p>
                <p>
                  Waist:{" "}
                  {waistChangeSinceStart !== undefined ? (
                    <span className="font-medium text-foreground">{formatSigned(waistChangeSinceStart, lengthUnit, 1)}</span>
                  ) : (
                    "—"
                  )}
                </p>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Baseline: first weight check-in (fallback profile)</p>
            </div>

            <div className="rounded-lg border p-3">
              <p className="text-sm font-medium text-foreground flex items-center gap-2">
                <ClipboardCheck className="h-4 w-4 text-muted-foreground" />
                Tracking health
              </p>
              <div className="mt-2 grid gap-1 text-sm text-muted-foreground">
                <p>Weight check-ins: {totalWeightCheckIns}</p>
                <p>Last weight check-in: {daysSinceLastWeight !== undefined ? `${daysSinceLastWeight} day(s) ago` : "—"}</p>
                <p>Last activity: {latestAnyCheckIn ? new Date(latestAnyCheckIn.submittedAt).toLocaleDateString() : "—"}</p>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Helps you spot low compliance quickly</p>
            </div>

            <div className="rounded-lg border p-3 md:col-span-2">
              <p className="text-sm font-medium text-foreground flex items-center gap-2">
                <Ruler className="h-4 w-4 text-muted-foreground" />
                Latest measurements (from last weight check-in)
              </p>
              <div className="mt-2 grid gap-1 text-sm text-muted-foreground md:grid-cols-2 md:grid">
                <p>Waist: {latestWaist !== undefined ? `${round1(latestWaist)} ${lengthUnit}` : "—"}</p>
                <p>Chest: {latestChest !== undefined ? `${round1(latestChest)} ${lengthUnit}` : "—"}</p>
                <p>Arms: {latestArms !== undefined ? `${round1(latestArms)} ${lengthUnit}` : "—"}</p>
                <p>Thighs: {latestThighs !== undefined ? `${round1(latestThighs)} ${lengthUnit}` : "—"}</p>
                <p>Body fat: {latestBodyFat !== undefined ? `${round1(latestBodyFat)}%` : "—"}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick actions</CardTitle>
            <CardDescription>Jump where you need.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full" onClick={() => navigate(`/check-ins?clientId=${clientId}`)}>
              <ClipboardCheck className="h-4 w-4 mr-2" />
              Open check-ins
            </Button>
            <Button variant="outline" className="w-full" onClick={() => navigate(`/clients/${clientId}/edit`)}>
              <Edit className="h-4 w-4 mr-2" />
              Edit profile
            </Button>
            <Button variant="outline" className="w-full">
              <Mail className="h-4 w-4 mr-2" />
              Email client
            </Button>

            {/* ✅ Notes (coach-only) */}
            <div className="pt-2">
              <p className="text-xs text-muted-foreground mb-2">Notes (coach-only)</p>

              <form
                className="space-y-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!noteDraft.trim()) return;
                  createNoteMutation.mutate();
                }}
              >
                <textarea
                  value={noteDraft}
                  onChange={(e) => setNoteDraft(e.target.value)}
                  placeholder="Write a private note: injuries, preferences, follow-up tasks..."
                  className="w-full min-h-[90px] rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                />
                <div className="flex justify-end">
                  <Button type="submit" size="sm" disabled={createNoteMutation.isPending || !noteDraft.trim()}>
                    {createNoteMutation.isPending ? "Saving..." : "Save note"}
                  </Button>
                </div>
              </form>

              <div className="mt-3 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-muted-foreground">Recent</p>
                  {isLoadingNotes ? <span className="text-xs text-muted-foreground">Loading…</span> : null}
                </div>

                {notesError ? (
                  <div className="rounded-lg border p-2 text-sm text-destructive">Unable to load notes.</div>
                ) : clientNotes.length === 0 ? (
                  <div className="rounded-lg border p-2 text-sm text-muted-foreground">No notes yet.</div>
                ) : (
                  <div className="space-y-2">
                    {clientNotes.slice(0, 5).map((note: any) => {
                      const stamp = note.updatedAt ?? note.createdAt;
                      const isEditing = editingNoteId === note.id;

                      return (
                        <div key={note.id} className="rounded-lg border p-2">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0 flex-1">
                              {isEditing ? (
                                <textarea
                                  value={editingNoteContent}
                                  onChange={(e) => setEditingNoteContent(e.target.value)}
                                  className="w-full min-h-[80px] rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                />
                              ) : (
                                <p className="text-sm whitespace-pre-wrap break-words">{note.content}</p>
                              )}

                              <p className="text-xs text-muted-foreground mt-1">
                                {stamp ? new Date(stamp).toLocaleString() : ""}
                              </p>
                            </div>

                            <div className="flex flex-col items-end gap-1">
                              {isEditing ? (
                                <>
                                  <Button
                                    type="button"
                                    variant="default"
                                    size="sm"
                                    onClick={() =>
                                      updateNoteMutation.mutate({
                                        noteId: note.id,
                                        content: editingNoteContent.trim(),
                                      })
                                    }
                                    disabled={updateNoteMutation.isPending || !editingNoteContent.trim()}
                                  >
                                    {updateNoteMutation.isPending ? "Saving..." : "Save"}
                                  </Button>
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => {
                                      setEditingNoteId(null);
                                      setEditingNoteContent("");
                                    }}
                                  >
                                    Cancel
                                  </Button>
                                </>
                              ) : (
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => {
                                    setEditingNoteId(note.id);
                                    setEditingNoteContent(note.content ?? "");
                                  }}
                                >
                                  Edit
                                </Button>
                              )}

                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteNoteMutation.mutate(note.id)}
                                disabled={deleteNoteMutation.isPending}
                              >
                                Delete
                              </Button>
                            </div>
                          </div>
                        </div>
                      );
                    })}

                    {clientNotes.length > 5 ? (
                      <p className="text-xs text-muted-foreground">Showing latest 5 of {clientNotes.length}</p>
                    ) : null}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Drill-down */}
      <Tabs defaultValue="plans" className="space-y-4">
        <TabsList>
          <TabsTrigger value="plans">Plans</TabsTrigger>
          <TabsTrigger value="checkins">Check-ins</TabsTrigger>
          <TabsTrigger value="photos">Photos</TabsTrigger>
        </TabsList>

        <TabsContent value="checkins">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Check-ins</CardTitle>
              <CardDescription>Review this client's check-ins.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-wrap items-center gap-2">
              <Button variant="outline" onClick={() => navigate(`/check-ins?clientId=${clientId}`)}>
                <ClipboardCheck className="h-4 w-4 mr-2" />
                Pending
              </Button>
              <Button variant="outline" onClick={() => navigate(`/check-ins?clientId=${clientId}`)}>
                <Eye className="h-4 w-4 mr-2" />
                Reviewed
              </Button>
              <Button variant="outline" onClick={() => navigate(`/check-ins?clientId=${clientId}`)}>
                <Eye className="h-4 w-4 mr-2" />
                All
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="plans">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <div className="rounded-md bg-primary/10 p-2">
                    <Dumbbell className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Workout Plan</CardTitle>
                    <CardDescription>Assign a training program and track it here.</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {activeWorkoutAssignment ? (
                  <div className="rounded-lg border border-primary/20 p-3">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <p className="font-semibold">{assignedWorkoutPlan?.name ?? "Assigned plan"}</p>
                        {assignedWorkoutPlan?.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2">{assignedWorkoutPlan.description}</p>
                        )}
                      </div>
                      <Badge variant={activeWorkoutAssignment.isActive ? "secondary" : "outline"}>
                        {activeWorkoutAssignment.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    <div className="mt-3 grid gap-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>Start: {formatDate(activeWorkoutAssignment.startDate)}</span>
                      </div>
                      {activeWorkoutAssignment.durationDays && (
                        <div className="flex items-center gap-2">
                          <Target className="h-4 w-4" />
                          <span>
                            Duration: {activeWorkoutAssignment.durationDays} day{activeWorkoutAssignment.durationDays > 1 ? "s" : ""}
                          </span>
                        </div>
                      )}
                      {activeWorkoutAssignment.endDate && (
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          <span>Ends: {formatDate(activeWorkoutAssignment.endDate)}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <p className="text-muted-foreground">No workout plan assigned yet.</p>
                )}

                <form
                  className="space-y-3"
                  onSubmit={(e) => {
                    e.preventDefault();
                    assignWorkoutMutation.mutate();
                  }}
                >
                  <div className="space-y-2">
                    <Label htmlFor="workoutPlan">Assign plan</Label>
                    <select
                      id="workoutPlan"
                      className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      value={selectedWorkoutPlan}
                      onChange={(e) => setSelectedWorkoutPlan(e.target.value)}
                    >
                      <option value="">Select a workout plan</option>
                      {workoutPlans.map((plan) => (
                        <option key={plan.id} value={plan.id}>
                          {plan.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="workoutStart">Start date</Label>
                      <Input id="workoutStart" type="date" value={workoutStartDate} onChange={(e) => setWorkoutStartDate(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="workoutDuration">Duration (days)</Label>
                      <Input
                        id="workoutDuration"
                        type="number"
                        min={1}
                        placeholder="Optional"
                        value={workoutDuration}
                        onChange={(e) => setWorkoutDuration(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" className="shadow-energy" disabled={assignWorkoutMutation.isPending || !selectedWorkoutPlan}>
                      {assignWorkoutMutation.isPending ? "Assigning..." : "Assign workout plan"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <div className="rounded-md bg-energy/10 p-2">
                    <Utensils className="h-5 w-5 text-energy" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Diet Plan</CardTitle>
                    <CardDescription>Assign a nutrition program and track it here.</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {activeDietAssignment ? (
                  <div className="rounded-lg border border-energy/30 p-3">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <p className="font-semibold">{assignedDietPlan?.name ?? "Assigned plan"}</p>
                        {assignedDietPlan?.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2">{assignedDietPlan.description}</p>
                        )}
                      </div>
                      <Badge variant={activeDietAssignment.isActive ? "secondary" : "outline"}>
                        {activeDietAssignment.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    <div className="mt-3 grid gap-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>Start: {formatDate(activeDietAssignment.startDate)}</span>
                      </div>
                      {activeDietAssignment.durationDays && (
                        <div className="flex items-center gap-2">
                          <Target className="h-4 w-4" />
                          <span>
                            Duration: {activeDietAssignment.durationDays} day{activeDietAssignment.durationDays > 1 ? "s" : ""}
                          </span>
                        </div>
                      )}
                      {activeDietAssignment.endDate && (
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          <span>Ends: {formatDate(activeDietAssignment.endDate)}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <p className="text-muted-foreground">No diet plan assigned yet.</p>
                )}

                <form
                  className="space-y-3"
                  onSubmit={(e) => {
                    e.preventDefault();
                    assignDietMutation.mutate();
                  }}
                >
                  <div className="space-y-2">
                    <Label htmlFor="dietPlan">Assign plan</Label>
                    <select
                      id="dietPlan"
                      className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      value={selectedDietPlan}
                      onChange={(e) => setSelectedDietPlan(e.target.value)}
                    >
                      <option value="">Select a diet plan</option>
                      {dietPlans.map((plan) => (
                        <option key={plan.id} value={plan.id}>
                          {plan.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="dietStart">Start date</Label>
                      <Input id="dietStart" type="date" value={dietStartDate} onChange={(e) => setDietStartDate(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dietDuration">Duration (days)</Label>
                      <Input
                        id="dietDuration"
                        type="number"
                        min={1}
                        placeholder="Optional"
                        value={dietDuration}
                        onChange={(e) => setDietDuration(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" className="shadow-energy" disabled={assignDietMutation.isPending || !selectedDietPlan}>
                      {assignDietMutation.isPending ? "Assigning..." : "Assign diet plan"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="photos">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Progress Photos</CardTitle>
              <CardDescription>Planned in Sprint 4</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">No photos uploaded yet.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default ClientDetailPage;
