using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models.WorkoutPlans;

public class WorkoutPlanEntity
{
    [Key]
    public Guid Id { get; set; }

    public Guid CoachId { get; set; }

    [MaxLength(200)]
    public string Name { get; set; } = "";

    public bool IsPublished { get; set; }

    // Entire workout plan stored as JSON
    public string DefinitionJson { get; set; } = "";

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
