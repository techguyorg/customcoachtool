using System.Security.Claims;
using FitCoachPro.Api.Data;
using FitCoachPro.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;

namespace FitCoachPro.Api.Endpoints;

public static class DashboardEndpoints
{
    public static void MapDashboardEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/dashboard").RequireAuthorization();

        group.MapGet("/coach", [Authorize(Roles = "coach")] async (ClaimsPrincipal principal, AppDbContext db) =>
        {
            var coachIdStr = principal.FindFirstValue(ClaimTypes.NameIdentifier) ?? principal.FindFirstValue("sub");
            if (coachIdStr is null || !Guid.TryParse(coachIdStr, out var coachId))
                return Results.Unauthorized();

            var today = DateTime.UtcNow.Date;
            var nowUtc = DateTime.UtcNow;
            var overdueCutoff = nowUtc.AddDays(-7);
            const int expiringDaysThreshold = 7;
            const int lowComplianceThreshold = 60; // percent

            // Active clients for this coach
            var activeClientIds = await db.CoachClients
                .AsNoTracking()
                .Where(x => x.CoachId == coachId && x.IsActive)
                .Select(x => x.ClientId)
                .ToListAsync();

            var totalClients = activeClientIds.Count;
            var activeClients = totalClients;

            // Name lookup for active clients
            var clientNames = await db.Users
                .AsNoTracking()
                .Where(u => activeClientIds.Contains(u.Id))
                .Select(u => new { u.Id, Name = u.Profile!.DisplayName ?? u.Email })
                .ToDictionaryAsync(x => x.Id, x => x.Name);

            // Top pending check-ins (actionable list)
            var pendingCheckInRows = await db.CheckIns
                .AsNoTracking()
                .Where(c => c.CoachId == coachId && c.Status == CheckInStatus.Pending && activeClientIds.Contains(c.ClientId))
                .OrderByDescending(c => c.SubmittedAt)
                .Take(8)
                .Select(c => new
                {
                    c.Id,
                    c.ClientId,
                    c.Type,
                    c.SubmittedAt
                })
                .ToListAsync();

            var pendingCheckIns = await db.CheckIns
                .AsNoTracking()
                .CountAsync(c => c.CoachId == coachId && c.Status == CheckInStatus.Pending && activeClientIds.Contains(c.ClientId));

            var workoutPlansCreated = await db.WorkoutPlans
                .AsNoTracking()
                .CountAsync(x => x.CoachId == coachId);

            var dietPlansCreated = await db.DietPlans
                .AsNoTracking()
                .CountAsync(x => x.CoachId == coachId);

            // Renewals (also used to drive expiring attention items)
            var workoutRenewals = await db.ClientWorkoutPlans
                .AsNoTracking()
                .Include(cwp => cwp.WorkoutPlan)
                .Where(cwp =>
                    cwp.IsActive &&
                    cwp.WorkoutPlan != null &&
                    cwp.WorkoutPlan.CoachId == coachId &&
                    activeClientIds.Contains(cwp.ClientId))
                .Select(cwp => new
                {
                    cwp.ClientId,
                    planId = cwp.WorkoutPlanId,
                    planName = cwp.WorkoutPlan!.Name,
                    planType = "workout",
                    renewalDate = cwp.EndDate ?? cwp.StartDate.AddDays(Math.Max(1, cwp.WorkoutPlan.DurationWeeks) * 7)
                })
                .ToListAsync();

            var dietRenewals = await db.ClientDietPlans
                .AsNoTracking()
                .Include(cdp => cdp.DietPlan)
                .Where(cdp =>
                    cdp.IsActive &&
                    cdp.DietPlan != null &&
                    cdp.DietPlan.CoachId == coachId &&
                    activeClientIds.Contains(cdp.ClientId))
                .Select(cdp => new
                {
                    cdp.ClientId,
                    planId = cdp.DietPlanId,
                    planName = cdp.DietPlan!.Name,
                    planType = "diet",
                    renewalDate = cdp.EndDate ?? cdp.StartDate.AddDays(28)
                })
                .ToListAsync();

            var upcomingRenewals = workoutRenewals
                .Concat(dietRenewals)
                .Where(r => r.renewalDate >= today.AddDays(-1))
                .OrderBy(r => r.renewalDate)
                .Take(10)
                .Select(r => new
                {
                    r.planId,
                    r.planName,
                    r.planType,
                    r.renewalDate,
                    clientId = r.ClientId,
                    clientName = clientNames.TryGetValue(r.ClientId, out var name) ? name : "Client",
                    daysRemaining = (int)Math.Ceiling((r.renewalDate - today).TotalDays)
                })
                .ToList();

            // Overdue weight check-ins: no weight check-in in last 7 days
            var lastWeightByClient = await db.CheckIns
                .AsNoTracking()
                .Where(c => c.CoachId == coachId && c.Type == CheckInType.Weight && activeClientIds.Contains(c.ClientId))
                .GroupBy(c => c.ClientId)
                .Select(g => new { ClientId = g.Key, LastSubmittedAt = g.Max(x => x.SubmittedAt) })
                .ToListAsync();

            var lastWeightMap = lastWeightByClient.ToDictionary(x => x.ClientId, x => x.LastSubmittedAt);
            var overdueClientIds = activeClientIds
                .Where(cid => !lastWeightMap.TryGetValue(cid, out var last) || last < overdueCutoff)
                .ToList();

            // Low diet compliance: avg of last 3 diet check-ins < threshold
            var recentDietRows = await db.CheckIns
                .AsNoTracking()
                .Where(c => c.CoachId == coachId && c.Type == CheckInType.Diet && c.DietCompliance.HasValue && activeClientIds.Contains(c.ClientId))
                .OrderByDescending(c => c.SubmittedAt)
                .Select(c => new { c.ClientId, c.SubmittedAt, Compliance = c.DietCompliance!.Value })
                .Take(250)
                .ToListAsync();

            var lowComplianceClientIds = recentDietRows
                .GroupBy(x => x.ClientId)
                .Select(g => new
                {
                    ClientId = g.Key,
                    Avg = g.Take(3).Average(x => x.Compliance),
                    LastAt = g.Take(1).Select(x => x.SubmittedAt).FirstOrDefault()
                })
                .Where(x => x.Avg < lowComplianceThreshold)
                .OrderByDescending(x => x.LastAt)
                .Select(x => x.ClientId)
                .ToList();

            // Expiring plans: renewals within next N days
            var expiringRenewals = upcomingRenewals
                .Where(r => r.daysRemaining >= 0 && r.daysRemaining <= expiringDaysThreshold)
                .OrderBy(r => r.daysRemaining)
                .ToList();

            // Attention items (prioritized)
            var attention = new List<object>();

            // 1) Pending check-ins
            foreach (var row in pendingCheckInRows.Take(5))
            {
                attention.Add(new
                {
                    clientId = row.ClientId,
                    clientName = clientNames.TryGetValue(row.ClientId, out var nm) ? nm : "Client",
                    type = row.Type,
                    summary = $"{FormatCheckInType(row.Type)} check-in pending review",
                    submittedAt = row.SubmittedAt,
                    reason = "pending_checkin"
                });
            }

            // 2) Overdue weight check-ins
            foreach (var clientId in overdueClientIds)
            {
                if (attention.Count >= 8) break;
                var last = lastWeightMap.TryGetValue(clientId, out var dt) ? dt : (DateTime?)null;
                attention.Add(new
                {
                    clientId,
                    clientName = clientNames.TryGetValue(clientId, out var nm) ? nm : "Client",
                    type = CheckInType.Weight,
                    summary = last == null
                        ? "Weight check-in overdue (no submissions yet)"
                        : $"Weight check-in overdue (last {ToRelativeShort(last.Value)})",
                    submittedAt = last,
                    reason = "overdue_weight"
                });
            }

            // 3) Expiring plans
            foreach (var r in expiringRenewals)
            {
                if (attention.Count >= 10) break;
                attention.Add(new
                {
                    clientId = r.clientId,
                    clientName = r.clientName,
                    type = r.planType,
                    summary = $"{(r.planType == "workout" ? "Workout" : "Diet")} plan expiring in {r.daysRemaining} day(s)",
                    submittedAt = (DateTime?)null,
                    reason = "plan_expiring"
                });
            }

            // 4) Low compliance
            foreach (var clientId in lowComplianceClientIds)
            {
                if (attention.Count >= 12) break;
                attention.Add(new
                {
                    clientId,
                    clientName = clientNames.TryGetValue(clientId, out var nm) ? nm : "Client",
                    type = CheckInType.Diet,
                    summary = "Low diet compliance in recent check-ins",
                    submittedAt = (DateTime?)null,
                    reason = "low_compliance"
                });
            }

            // Compliance trend (coach-wide)
            var complianceSamples = await db.CheckIns
                .AsNoTracking()
                .Where(c => c.CoachId == coachId && c.Type == CheckInType.Diet && c.DietCompliance.HasValue && activeClientIds.Contains(c.ClientId))
                .OrderByDescending(c => c.SubmittedAt)
                .Take(12)
                .Select(c => c.DietCompliance!.Value)
                .ToListAsync();

            var averageCompliance = complianceSamples.Any()
                ? Math.Round(complianceSamples.Average(), 1)
                : 0;

            var recentCompliance = complianceSamples.Take(6).ToList();
            var previousCompliance = complianceSamples.Skip(6).ToList();
            var recentAverage = recentCompliance.Any() ? recentCompliance.Average() : averageCompliance;
            var previousAverage = previousCompliance.Any() ? previousCompliance.Average() : averageCompliance;

            var complianceTrend = new
            {
                average = averageCompliance,
                change = Math.Round(recentAverage - previousAverage, 1),
                sampleSize = complianceSamples.Count
            };

            var pendingCheckInItems = pendingCheckInRows
                .Take(6)
                .Select(c => new
                {
                    id = c.Id,
                    clientId = c.ClientId,
                    clientName = clientNames.TryGetValue(c.ClientId, out var nm) ? nm : "Client",
                    type = c.Type,
                    summary = $"{FormatCheckInType(c.Type)} check-in pending",
                    submittedAt = c.SubmittedAt
                });

            return Results.Ok(new
            {
                totalClients,
                activeClients,
                pendingCheckIns,
                workoutPlansCreated,
                dietPlansCreated,
                pendingCheckInItems,
                attentionItems = attention.Take(10),
                upcomingRenewals,
                complianceTrend
            });
        });

        group.MapGet("/client", [Authorize(Roles = "client")] async (ClaimsPrincipal principal, AppDbContext db) =>
        {
            var idStr = principal.FindFirstValue(ClaimTypes.NameIdentifier) ?? principal.FindFirstValue("sub");
            if (idStr is null || !Guid.TryParse(idStr, out var uid))
                return Results.Unauthorized();

            var user = await db.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == uid);
            if (user is null) return Results.Unauthorized();

            var p = user.Profile;

            var currentWeight = (double)(p?.CurrentWeight ?? 0);
            var startWeight = (double)(p?.StartWeight ?? p?.CurrentWeight ?? 0);
            var weightChange = currentWeight - startWeight;

            var startDate = p?.StartDate ?? DateTime.UtcNow.Date;
            var daysOnPlan = (int)Math.Max(0, (DateTime.UtcNow.Date - startDate.Date).TotalDays);

            return Results.Ok(new
            {
                currentWeight,
                weightChange,
                workoutsCompleted = 0,
                dietComplianceAverage = 0,
                daysOnPlan
            });
        });
    }

    private static string FormatCheckInType(string type) => type switch
    {
        CheckInType.Weight => "Weight",
        CheckInType.Workout => "Workout",
        CheckInType.Diet => "Diet",
        CheckInType.Photos => "Progress photos",
        _ when string.IsNullOrWhiteSpace(type) => "Check-in",
        _ when type.Length == 1 => type.ToUpper(),
        _ => $"{char.ToUpper(type[0])}{type.Substring(1)}"
    };

    private static string ToRelativeShort(DateTime utc)
    {
        var days = (int)Math.Floor((DateTime.UtcNow - utc).TotalDays);
        if (days <= 0) return "today";
        if (days == 1) return "1 day ago";
        return $"{days} days ago";
    }
}
