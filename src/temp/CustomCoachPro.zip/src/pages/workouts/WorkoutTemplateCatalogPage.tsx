import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowLeft,
  Search,
  SlidersHorizontal,
  Clock,
  Dumbbell,
  Check,
} from "lucide-react";

import { PageHeader } from "@/components/shared/PageHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { EmptyState } from "@/components/shared/EmptyState";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import workoutPlanService from "@/services/workoutPlanService";
import type { WorkoutPlan } from "@/types";

/* -----------------------------------------------------
   EXPLORE WORKOUT PROGRAMS
   Polished · Lively · Mobile-first
----------------------------------------------------- */

const DURATIONS = [4, 6, 8, 12];
const DAYS = [3, 4, 5, 6];
const EQUIPMENT = ["Bodyweight", "Dumbbells", "Gym"];
const MUSCLES = ["Full Body", "Chest", "Back", "Legs", "Core"];

function ProgramCard({ plan }: { plan: WorkoutPlan }) {
  const navigate = useNavigate();
  const daysPerWeek = plan.days?.length ?? 0;

  return (
    <Card className="group transition hover:-translate-y-0.5 hover:shadow-lg">
      <CardHeader className="space-y-2">
        <CardTitle className="text-base leading-tight">
          {plan.name}
        </CardTitle>

        <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {plan.durationWeeks} weeks
          </span>
          <span>·</span>
          <span className="flex items-center gap-1">
            <Dumbbell className="h-3 w-3" />
            {daysPerWeek} days / week
          </span>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground line-clamp-2">
          {plan.description ||
            "A balanced workout program designed to build consistency and progress safely."}
        </p>

        {/* TAGS (future-ready, graceful fallback) */}
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary">Pro-designed</Badge>
        </div>

        <div className="flex items-center gap-2 pt-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => navigate(`/workout-plans/${plan.id}`)}
          >
            View details
          </Button>

          <Button
            size="sm"
            className="flex-1"
            onClick={async () => {
              const created = await workoutPlanService.create({
                name: `${plan.name} (Copy)`,
                description: plan.description,
                durationWeeks: plan.durationWeeks,
                days: plan.days,
              });

              navigate(`/workout-plans/${created.id}/edit`);
            }}
          >
            Use program
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* -----------------------------------------------------
   FILTER SHEET (MOBILE-FIRST)
----------------------------------------------------- */

function FilterSheet({
  open,
  onClose,
  duration,
  setDuration,
  days,
  setDays,
  equipment,
  setEquipment,
  muscles,
  setMuscles,
}: {
  open: boolean;
  onClose: () => void;
  duration: number | null;
  setDuration: (v: number | null) => void;
  days: number | null;
  setDays: (v: number | null) => void;
  equipment: string[];
  setEquipment: (v: string[]) => void;
  muscles: string[];
  setMuscles: (v: string[]) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Refine programs</DialogTitle>
        </DialogHeader>

        <div className="space-y-5">
          {/* Duration */}
          <div className="space-y-2">
            <div className="text-sm font-medium">Duration</div>
            {DURATIONS.map((w) => (
              <Button
                key={w}
                variant={duration === w ? "secondary" : "ghost"}
                className="w-full justify-between"
                onClick={() =>
                  setDuration(duration === w ? null : w)
                }
              >
                {w} weeks
                {duration === w && <Check className="h-4 w-4" />}
              </Button>
            ))}
          </div>

          {/* Days */}
          <div className="space-y-2">
            <div className="text-sm font-medium">Days per week</div>
            {DAYS.map((d) => (
              <Button
                key={d}
                variant={days === d ? "secondary" : "ghost"}
                className="w-full justify-between"
                onClick={() => setDays(days === d ? null : d)}
              >
                {d} days / week
                {days === d && <Check className="h-4 w-4" />}
              </Button>
            ))}
          </div>

          {/* Equipment */}
          <div className="space-y-2">
            <div className="text-sm font-medium">Equipment</div>
            <div className="flex flex-wrap gap-2">
              {EQUIPMENT.map((e) => (
                <Button
                  key={e}
                  size="sm"
                  variant={equipment.includes(e) ? "secondary" : "outline"}
                  onClick={() =>
                    setEquipment((prev) =>
                      prev.includes(e)
                        ? prev.filter((x) => x !== e)
                        : [...prev, e]
                    )
                  }
                >
                  {e}
                </Button>
              ))}
            </div>
          </div>

          {/* Muscles */}
          <div className="space-y-2">
            <div className="text-sm font-medium">Muscle focus</div>
            <div className="flex flex-wrap gap-2">
              {MUSCLES.map((m) => (
                <Button
                  key={m}
                  size="sm"
                  variant={muscles.includes(m) ? "secondary" : "outline"}
                  onClick={() =>
                    setMuscles((prev) =>
                      prev.includes(m)
                        ? prev.filter((x) => x !== m)
                        : [...prev, m]
                    )
                  }
                >
                  {m}
                </Button>
              ))}
            </div>
          </div>

          <Button onClick={onClose}>Apply filters</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* -----------------------------------------------------
   PAGE
----------------------------------------------------- */

export default function WorkoutTemplateCatalogPage() {
  const navigate = useNavigate();

  const [search, setSearch] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [duration, setDuration] = useState<number | null>(null);
  const [days, setDays] = useState<number | null>(null);
  const [equipment, setEquipment] = useState<string[]>([]);
  const [muscles, setMuscles] = useState<string[]>([]);

  const { data, isLoading } = useQuery({
    queryKey: ["workout-templates"],
    queryFn: () => workoutPlanService.listTemplates(),
  });

  const programs = useMemo(() => {
    let items = data?.items ?? [];

    if (search) {
      items = items.filter((p) =>
        p.name.toLowerCase().includes(search.toLowerCase())
      );
    }

    if (duration) {
      items = items.filter((p) => p.durationWeeks === duration);
    }

    if (days) {
      items = items.filter((p) => p.days?.length === days);
    }

    return items;
  }, [data, search, duration, days]);

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Explore workout programs"
        description="Find a proven program and customize it to match your goals."
        actions={
          <Button
            variant="ghost"
            onClick={() => navigate("/workout-plans")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        }
      />

      {/* SEARCH + FILTER */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="h-4 w-4 absolute left-3 top-2.5 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search programs by name…"
            className="pl-9"
          />
        </div>

        <Button
          variant="outline"
          size="icon"
          onClick={() => setShowFilters(true)}
        >
          <SlidersHorizontal className="h-4 w-4" />
        </Button>
      </div>

      {/* CONTENT */}
      {isLoading && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="h-44 rounded-lg bg-muted animate-pulse"
            />
          ))}
        </div>
      )}

      {!isLoading && programs.length === 0 && (
        <EmptyState
          icon={Dumbbell}
          title="No programs match your filters"
          description="Try adjusting your search or filters."
        />
      )}

      {!isLoading && programs.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {programs.map((plan) => (
            <ProgramCard key={plan.id} plan={plan} />
          ))}
        </div>
      )}

      <FilterSheet
        open={showFilters}
        onClose={() => setShowFilters(false)}
        duration={duration}
        setDuration={setDuration}
        days={days}
        setDays={setDays}
        equipment={equipment}
        setEquipment={setEquipment}
        muscles={muscles}
        setMuscles={setMuscles}
      />
    </div>
  );
}
