import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { ViewModeProvider } from "@/contexts/ViewModeContext";
import type { UserRole } from "@/types";

// Layouts
import { AppLayout } from "@/components/layout/AppLayout";
import { AuthLayout } from "@/components/layout/AuthLayout";

// Auth Pages
import { LoginPage } from "@/pages/auth/LoginPage";
import { RegisterPage } from "@/pages/auth/RegisterPage";

// Coach Pages
import { DashboardPage } from "@/pages/dashboard/DashboardPage";
import { ClientsPage } from "@/pages/clients/ClientsPage";
import { ClientDetailPage } from "@/pages/clients/ClientDetailPage";
import { NewClientPage } from "@/pages/clients/NewClientPage";
import EditClientPage from "@/pages/clients/EditClientPage";
import { CheckInsPage } from "@/pages/checkins/CheckInsPage";

// Workout Pages (CANONICAL)
import { WorkoutPlansPage } from "@/pages/workouts/WorkoutPlansPage";
import { CreateWorkoutPlanPage } from "@/pages/workouts/CreateWorkoutPlanPage";
import { EditWorkoutPlanPage } from "@/pages/workouts/EditWorkoutPlanPage";
import WorkoutPlanViewerPage from "@/pages/workouts/WorkoutPlanViewerPage";
import WorkoutTemplateCatalogPage from "@/pages/workouts/WorkoutTemplateCatalogPage";
import { WorkoutPlansReusePage } from "@/pages/workouts/WorkoutPlansReusePage";


// Diet Pages
import { DietPlansPage } from "@/pages/diet/DietPlansPage";
import { CreateDietPlanPage } from "@/pages/diet/CreateDietPlanPage";
import { EditDietPlanPage } from "@/pages/diet/EditDietPlanPage";
import { AssignDietPlanPage } from "@/pages/diet/AssignDietPlanPage";

// Analytics & Catalogs
import { AnalyticsPage } from "@/pages/analytics/AnalyticsPage";
import { ExerciseCatalogPage } from "@/pages/catalog/ExerciseCatalogPage";
import { FoodCatalogPage } from "@/pages/catalog/FoodCatalogPage";

// Client Pages
import { MyPlanPage } from "@/pages/client/MyPlanPage";
import { CheckInPage } from "@/pages/client/CheckInPage";
import { ProgressPage } from "@/pages/client/ProgressPage";

// Admin & Settings
import { AdminPage } from "@/pages/admin/AdminPage";
import { SettingsPage } from "@/pages/settings/SettingsPage";

import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

/* ---------------------------------- */
/* Utility Components                  */
/* ---------------------------------- */

function LoadingScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
    </div>
  );
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  if (isLoading) return <LoadingScreen />;
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function RoleRoute({
  allowed,
  children,
}: {
  allowed: UserRole[];
  children: React.ReactNode;
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) return <LoadingScreen />;
  if (!user) return <Navigate to="/login" replace />;

  if (!allowed.includes(user.role)) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading, user } = useAuth();

  if (isLoading) return <LoadingScreen />;

  if (isAuthenticated) {
    if (user?.role === "admin") return <Navigate to="/admin" replace />;
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
}

/* ---------------------------------- */
/* Routes                              */
/* ---------------------------------- */

function AppRoutes() {
  return (
    <Routes>
      {/* Public */}
      <Route
        element={
          <PublicRoute>
            <AuthLayout />
          </PublicRoute>
        }
      >
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
      </Route>

      {/* Protected */}
      <Route
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        {/* Dashboard */}
        <Route
          path="/dashboard"
          element={
            <RoleRoute allowed={["coach", "client"]}>
              <DashboardPage />
            </RoleRoute>
          }
        />

        {/* Settings */}
        <Route
          path="/settings"
          element={
            <RoleRoute allowed={["coach", "client"]}>
              <SettingsPage />
            </RoleRoute>
          }
        />

        {/* Admin */}
        <Route
          path="/admin"
          element={
            <RoleRoute allowed={["admin"]}>
              <AdminPage />
            </RoleRoute>
          }
        />

        {/* Clients */}
        <Route
          path="/clients"
          element={
            <RoleRoute allowed={["coach"]}>
              <ClientsPage />
            </RoleRoute>
          }
        />
        <Route
          path="/clients/new"
          element={
            <RoleRoute allowed={["coach"]}>
              <NewClientPage />
            </RoleRoute>
          }
        />
        <Route
          path="/clients/:id/edit"
          element={
            <RoleRoute allowed={["coach"]}>
              <EditClientPage />
            </RoleRoute>
          }
        />
        <Route
          path="/clients/:id"
          element={
            <RoleRoute allowed={["coach"]}>
              <ClientDetailPage />
            </RoleRoute>
          }
        />

        {/* ============================= */}
        {/* Workout Plans (CANONICAL)     */}
        {/* ============================= */}

        {/* <Route
          path="/workout-plans"
          element={
            <RoleRoute allowed={["coach"]}>
              <WorkoutPlansPage />
            </RoleRoute>
          }
        /> */}

        <Route path="/workout-plans">
        <Route index element={<WorkoutPlansEntry />} />

        {/* Coach */}
        <Route path="coach" element={<CoachWorkoutDashboard />} />
        <Route path="coach/drafts" element={<CoachDraftsPage />} />
        <Route path="coach/templates" element={<CoachTemplatesPage />} />
        <Route path="coach/assigned" element={<CoachAssignedPage />} />

        {/* Client */}
        <Route path="client" element={<ClientWorkoutDashboard />} />
        <Route path="client/drafts" element={<ClientDraftsPage />} />
        <Route path="client/assigned" element={<ClientAssignedPlansPage />} />
        <Route path="client/explore" element={<ClientExploreTemplatesPage />} />

        {/* Admin */}
        <Route path="admin/templates" element={<AdminTemplatesPage />} />

        {/* Shared */}
        <Route path="new" element={<CreateWorkoutPlanPage />} />
        <Route path=":id/edit" element={<EditWorkoutPlanPage />} />
        <Route path=":id" element={<WorkoutPlanViewerPage />} />
      </Route>

      <Route
        path="/workout-plans/coach/drafts"
        element={
          <RoleRoute allowed={["coach"]}>
            <CoachDraftsPage />
          </RoleRoute>
        }
      />

      <Route
        path="/workout-plans/coach/templates"
        element={
          <RoleRoute allowed={["coach"]}>
            <CoachTemplatesPage />
          </RoleRoute>
        }
      />

      <Route
        path="/workout-plans/coach/assigned"
        element={
          <RoleRoute allowed={["coach"]}>
            <CoachAssignedPage />
          </RoleRoute>
        }
      />

      <Route
        path="/client/workouts"
        element={
          <RoleRoute allowed={["client"]}>
            <ClientWorkoutDashboard />
          </RoleRoute>
        }
      />

      <Route
        path="/client/workouts/assigned"
        element={
          <RoleRoute allowed={["client"]}>
            <ClientAssignedPlansPage />
          </RoleRoute>
        }
      />

      <Route
        path="/client/workouts/drafts"
        element={
          <RoleRoute allowed={["client"]}>
            <ClientDraftsPage />
          </RoleRoute>
        }
      />

      <Route
        path="/admin/workout-templates"
        element={
          <RoleRoute allowed={["admin"]}>
            <AdminTemplatesPage />
          </RoleRoute>
        }
      />



        <Route
          path="/workout-plans/new"
          element={
            <RoleRoute allowed={["coach"]}>
              <CreateWorkoutPlanPage />
            </RoleRoute>
          }
        />

        <Route
          path="/workout-plans/:id/edit"
          element={
            <RoleRoute allowed={["coach"]}>
              <EditWorkoutPlanPage />
            </RoleRoute>
          }
        />

        <Route
          path="/workout-plans/:id"
          element={
            <RoleRoute allowed={["coach"]}>
              <WorkoutPlanViewerPage />
            </RoleRoute>
          }
        />

        {/* Templates */}
        <Route
          path="/workout-templates"
          element={
            <RoleRoute allowed={["coach"]}>
              <WorkoutTemplateCatalogPage />
            </RoleRoute>
          }
        />

        {/* ---------------------------------- */}
        {/* SOFT-DEPRECATED WORKOUT ROUTES     */}
        {/* (kept as redirects – SAFE)         */}
        {/* ---------------------------------- */}

        <Route
          path="/workout-plans/reuse"
          element={
            <RoleRoute allowed={["coach"]}>
              <WorkoutPlansReusePage />
            </RoleRoute>
          }
        />

        <Route
          path="/workout-plans/:id/assign"
          element={<Navigate to="/workout-plans" replace />}
        />

        <Route
          path="/workout-library/:id"
          element={<Navigate to="/workout-plans" replace />}
        />

        {/* Catalogs */}
        <Route
          path="/exercise-catalog"
          element={
            <RoleRoute allowed={["coach"]}>
              <ExerciseCatalogPage />
            </RoleRoute>
          }
        />
        <Route
          path="/food-catalog"
          element={
            <RoleRoute allowed={["coach"]}>
              <FoodCatalogPage />
            </RoleRoute>
          }
        />

        {/* Diet */}
        <Route
          path="/diet-plans"
          element={
            <RoleRoute allowed={["coach"]}>
              <DietPlansPage />
            </RoleRoute>
          }
        />
        <Route
          path="/diet-plans/new"
          element={
            <RoleRoute allowed={["coach"]}>
              <CreateDietPlanPage />
            </RoleRoute>
          }
        />
        <Route
          path="/diet-plans/:id/edit"
          element={
            <RoleRoute allowed={["coach"]}>
              <EditDietPlanPage />
            </RoleRoute>
          }
        />
        <Route
          path="/diet-plans/:id/assign"
          element={
            <RoleRoute allowed={["coach"]}>
              <AssignDietPlanPage />
            </RoleRoute>
          }
        />

        <Route
          path="/check-ins"
          element={
            <RoleRoute allowed={["coach"]}>
              <CheckInsPage />
            </RoleRoute>
          }
        />

        {/* Analytics */}
        <Route
          path="/analytics"
          element={
            <RoleRoute allowed={["coach"]}>
              <AnalyticsPage />
            </RoleRoute>
          }
        />

        {/* Client */}
        <Route
          path="/my-plan"
          element={
            <RoleRoute allowed={["client"]}>
              <MyPlanPage />
            </RoleRoute>
          }
        />
        <Route
          path="/check-ins"
          element={
            <RoleRoute allowed={["client"]}>
              <CheckInPage />
            </RoleRoute>
          }
        />
        <Route
          path="/progress"
          element={
            <RoleRoute allowed={["client"]}>
              <ProgressPage />
            </RoleRoute>
          }
        />
      </Route>

      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <ViewModeProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AppRoutes />
          </BrowserRouter>
        </TooltipProvider>
      </ViewModeProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
