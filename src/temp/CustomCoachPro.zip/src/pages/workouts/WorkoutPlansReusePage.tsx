import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Edit3,
  Eye,
  Search,
  Clock,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { EmptyState } from "@/components/shared/EmptyState";
import { PageHeader } from "@/components/shared/PageHeader";

import workoutPlanService from "@/services/workoutPlanService";
import type { WorkoutPlan } from "@/types";

/* -----------------------------------------------------
   SYSTEM PLANS (EXCLUDED)
----------------------------------------------------- */
// const SYSTEM_COACH_IDS = new Set([
//   "00000000-0000-0000-0000-000000000000",
//   "00000000-0000-0000-0000-000000000001",
// ]);

/* -----------------------------------------------------
   FEATURED PLAN — CONTINUE WHERE YOU LEFT OFF
----------------------------------------------------- */
function FeaturedPlan({ plan }: { plan: WorkoutPlan }) {
  const navigate = useNavigate();

  return (
    <Card className="border-primary/40 bg-primary/5 shadow-sm">
      <CardContent className="p-6 space-y-4">
        <div className="flex items-center gap-2 text-xs text-primary">
          <Clock className="h-4 w-4" />
          Continue where you left off
        </div>

        <div className="space-y-1">
          <div className="text-lg font-semibold">
            {plan.name}
          </div>
          <div className="text-sm text-muted-foreground">
            {plan.durationWeeks} weeks · {plan.days?.length ?? "—"} days
          </div>
        </div>

        <div className="flex items-center gap-3 pt-2">
          <Button
            size="sm"
            onClick={() =>
              navigate(`/workout-plans/${plan.id}/edit`, {
                state: { from: "/workout-plans/reuse" },
              })
            }
          >
            <Edit3 className="h-4 w-4 mr-2" />
            Continue editing
          </Button>

          <Button
            size="sm"
            variant="ghost"
            onClick={() =>
              navigate(`/workout-plans/${plan.id}`)
            }
          >
            <Eye className="h-4 w-4 mr-2" />
            Preview
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* -----------------------------------------------------
   PLAN CARD — SECONDARY
----------------------------------------------------- */
function ReusePlanCard({ plan }: { plan: WorkoutPlan }) {
  const navigate = useNavigate();

  return (
    <Card className="group bg-muted/20 hover:bg-background hover:shadow-md hover:border-primary/30 transition">
      <CardContent className="p-5 space-y-4">
        <div className="space-y-1">
          <div className="font-semibold leading-tight text-sm">
            {plan.name}
          </div>
          <div className="text-xs text-muted-foreground">
            {plan.durationWeeks} weeks · {plan.days.length} days
          </div>
        </div>

        <div className="text-xs text-muted-foreground">
          Last updated{" "}
          {plan.updatedAt
            ? new Date(plan.updatedAt).toLocaleDateString()
            : "—"}
        </div>

        <div className="flex items-center gap-2 pt-2">
          <Button
            size="sm"
            className="flex-1"
            onClick={() =>
              navigate(`/workout-plans/${plan.id}/edit`, {
                state: { from: "/workout-plans/reuse" },
              })
            }
          >
            <Edit3 className="h-4 w-4 mr-2" />
            Edit
          </Button>

          <Button
            size="sm"
            variant="ghost"
            onClick={() =>
              navigate(`/workout-plans/${plan.id}`)
            }
          >
            <Eye className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* -----------------------------------------------------
   PAGE — REUSE MY PLANS (ELEVATED)
----------------------------------------------------- */
export function WorkoutPlansReusePage() {
  const navigate = useNavigate();

  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<"recent" | "name">("recent");

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["workout-plans"],
    queryFn: workoutPlanService.list,
  });

  const ownedPlans = useMemo(() => {
    return plans
      .filter((p) => p.coachId !== "00000000-0000-0000-0000-000000000000")
      .filter((p) =>
        p.name.toLowerCase().includes(search.toLowerCase())
      )
      .sort((a, b) => {
        if (sort === "name") {
          return a.name.localeCompare(b.name);
        }
        return (
          new Date(b.updatedAt ?? 0).getTime() -
          new Date(a.updatedAt ?? 0).getTime()
        );
      });
  }, [plans, search, sort]);

  const featured = ownedPlans[0];
  const rest = ownedPlans.slice(1);

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        title="Continue building a workout"
        description="Pick up where you left off or jump into another plan."
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/workout-plans")}
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back
            </Button>

            <Button
              variant="secondary"
              size="sm"
              onClick={() => navigate("/workout-plans/new")}
            >
              Create new plan
            </Button>
          </div>
        }
      />

      {/* CONTROLS */}
      <div className="flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
        <div className="relative md:w-80">
          <Search className="h-4 w-4 absolute left-3 top-2.5 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search your plans…"
            className="pl-9"
          />
        </div>

        <div className="flex gap-1 rounded-md border p-1 bg-muted/40">
          <Button
            size="sm"
            variant={sort === "recent" ? "secondary" : "ghost"}
            onClick={() => setSort("recent")}
          >
            Recently updated
          </Button>
          <Button
            size="sm"
            variant={sort === "name" ? "secondary" : "ghost"}
            onClick={() => setSort("name")}
          >
            Name
          </Button>
        </div>
      </div>

      {/* CONTENT */}
      {isLoading ? (
        <div className="h-40 rounded-lg bg-muted animate-pulse" />
      ) : ownedPlans.length === 0 ? (
        <EmptyState
          icon={Edit3}
          title="Nothing to continue yet"
          description="Create your first workout plan and it’ll show up here."
          actionLabel="Create a plan"
          onAction={() => navigate("/workout-plans/new")}
        />
      ) : (
        <>
          {featured && <FeaturedPlan plan={featured} />}

          {rest.length > 0 && (
            <div className="space-y-3">
              <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Other plans
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {rest.map((plan) => (
                  <ReusePlanCard key={plan.id} plan={plan} />
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default WorkoutPlansReusePage;
