import { api } from "./api";

export async function getWorkoutTemplates() {
  const res = await api.get("/workout-plans/templates");
  return res.data.data;
}

export async function cloneWorkoutTemplate(templateId: string) {
  const res = await api.post(`/workout-plans/templates/${templateId}/clone`);
  return res.data.data;
}
