using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models.Templates;

public class WorkoutTemplate
{
    public Guid Id { get; set; } = Guid.NewGuid();

    [MaxLength(256)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(1024)]
    public string? Description { get; set; }

    // e.g., "Beginner", "Hypertrophy", "Strength", "Fat Loss", "Powerlifting"
    [MaxLength(64)]
    public string? GoalTag { get; set; }

    // e.g., "3-day", "4-day", "5-day"
    [MaxLength(64)]
    public string? SplitTag { get; set; }

    public bool IsPublished { get; set; } = false;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<WorkoutTemplateDay> Days { get; set; } = new List<WorkoutTemplateDay>();
}
