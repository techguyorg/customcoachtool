using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models.Library;

public class ExerciseLibraryEquipment
{
    public Guid Id { get; set; } = Guid.NewGuid();

    [MaxLength(128)]
    public string Name { get; set; } = string.Empty; // e.g., Barbell, Dumbbell, Cable, Bodyweight, Machine

    public ICollection<ExerciseLibraryItemEquipment> Exercises { get; set; } = new List<ExerciseLibraryItemEquipment>();
}
