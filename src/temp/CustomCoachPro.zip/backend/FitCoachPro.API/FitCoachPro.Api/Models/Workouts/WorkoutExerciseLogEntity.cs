using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models.Workouts;

public class WorkoutExerciseLogEntity
{
    [Key]
    public Guid Id { get; set; }

    // Ownership
    public Guid WorkoutSessionId { get; set; }
    public Guid ClientId { get; set; }
    public Guid CoachId { get; set; }

    // Identification inside the workout
    public int DayOrder { get; set; }
    public int ExerciseOrder { get; set; }
    public string ExerciseName { get; set; } = "";

    // Execution data
    public int SetNumber { get; set; }
    public decimal? Weight { get; set; }
    public int? RepsPerformed { get; set; }
    public int? Rpe { get; set; }          // 1–10
    public string? Notes { get; set; }

    // Timing
    public DateTime LoggedAt { get; set; }
}
