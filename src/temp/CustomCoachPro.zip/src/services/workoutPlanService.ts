import type {
  ClientWorkoutPlan,
  WorkoutPlan,
} from "@/types";
import apiService from "./api";

/**
 * ✅ SINGLE SOURCE OF TRUTH (LOCKED)
 * - Stable public API
 * - Backend V2 aligned
 * - Admin / Coach / Client ready
 */
const V2_BASE = "/v2/workout-plans";
const EMPTY_GUID = "00000000-0000-0000-0000-000000000000";

/* ============================
   INPUT TYPES (STABLE)
============================ */

export type WorkoutExerciseInput = {
  exerciseId?: string;
  exerciseName?: string;
  sets: number;
  reps: string;
  restSeconds: number;
  tempo?: string;
  notes?: string;
  order: number;
};

export type WorkoutDayInput = {
  name: string;
  dayNumber: number;
  exercises: WorkoutExerciseInput[];
};

export type WorkoutPlanPayload = {
  name: string;
  description?: string;
  durationWeeks: number;
  days: WorkoutDayInput[];
};

export type UpdateWorkoutPlanPayload =
  Partial<Omit<WorkoutPlanPayload, "days">> & {
    days?: WorkoutDayInput[];
  };

export type AssignWorkoutPlanPayload = {
  clientId: string;
  workoutPlanId: string;
  startDate: string;
  durationDays?: number;
};

export type WorkoutTemplateFilters = {
  search?: string;
  muscle?: string;
  equipment?: string;
  difficulty?: string;
  goal?: string;
  page?: number;
  pageSize?: number;
};

export type WorkoutTemplateListResult = {
  items: WorkoutPlan[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  filters: {
    muscleGroups: string[];
    equipment: string[];
    difficulties: string[];
    goals: string[];
  };
};

/* ============================
   SERVICE IMPLEMENTATION
============================ */
function normalizeWorkoutPlan(doc: any): WorkoutPlan {
  return {
    id: doc.id,
    coachId: doc.coachId,
    name: doc.meta?.name ?? "",
    description: doc.meta?.description,
    durationWeeks: doc.meta?.durationWeeks ?? 0,
    isPublished: doc.meta?.isPublished ?? false,
    days: doc.days ?? [],
    createdAt: doc.createdAt,
    updatedAt: doc.updatedAt,
  };
}

const workoutPlanService = {
  /* ----------------------------------
     LIST ALL PLANS
     - Admin: everything
     - Coach: system + own
     - Client: usually unused
  ---------------------------------- */
  async list(): Promise<WorkoutPlan[]> {
    const raw = await apiService.get<any[]>(V2_BASE);
    return raw.map(normalizeWorkoutPlan);
  },


  /* ----------------------------------
     GET SINGLE PLAN
  ---------------------------------- */
  async get(id: string): Promise<WorkoutPlan> {
    const raw = await apiService.get<any>(`${V2_BASE}/${id}`);
    return normalizeWorkoutPlan(raw);
  },


  /* ----------------------------------
     CREATE PLAN
     Always returns full plan
  ---------------------------------- */
  async create(payload: WorkoutPlanPayload): Promise<{ id: string }> {
  const document = {
    meta: {
      name: payload.name,
      description: payload.description,
      durationWeeks: payload.durationWeeks,
      isPublished: false,
    },
    days: payload.days.map((day) => ({
      name: day.name,
      order: day.dayNumber,
      exercises: day.exercises.map((ex) => ({
        libraryExerciseId: ex.exerciseId ?? null,
        name: ex.exerciseName,
        sets: ex.sets,
        reps: ex.reps,
        restSeconds: ex.restSeconds,
        tempo: ex.tempo,
        notes: ex.notes,
        order: ex.order,
      })),
    })),
  };

  return apiService.post<{ id: string }>(
    "/v2/workout-plans",
    document
  );
},


  /* ----------------------------------
     UPDATE PLAN
  ---------------------------------- */
  async update(
    id: string,
    payload: UpdateWorkoutPlanPayload
  ): Promise<WorkoutPlan> {
    return apiService.put<WorkoutPlan>(
      `${V2_BASE}/${id}`,
      payload
    );
  },

  /* ----------------------------------
     DELETE PLAN
  ---------------------------------- */
  async remove(id: string): Promise<void> {
    await apiService.delete(`${V2_BASE}/${id}`);
  },

  /* ----------------------------------
     DUPLICATE PLAN
     (Backend-agnostic, safe)
  ---------------------------------- */
  async duplicate(id: string): Promise<WorkoutPlan> {
    const original = await this.get(id);

    return this.create({
      name: `${original.name} (Copy)`,
      description: original.description,
      durationWeeks: original.durationWeeks,
      days: original.days,
    });
  },

  /* ----------------------------------
     ASSIGN PLAN TO CLIENT
     Backend: POST /{id}/assign
  ---------------------------------- */
  async assign(
    payload: AssignWorkoutPlanPayload
  ): Promise<ClientWorkoutPlan> {
    const { workoutPlanId, ...body } = payload;

    return apiService.post<ClientWorkoutPlan>(
      `${V2_BASE}/${workoutPlanId}/assign`,
      body
    );
  },

  /* ----------------------------------
     SYSTEM TEMPLATES
     - Admin-owned (coachId === EMPTY_GUID)
     - Published only
     - Client-side filtered for now
  ---------------------------------- */
  async listTemplates(
    filters?: WorkoutTemplateFilters
  ): Promise<WorkoutTemplateListResult> {
    const allPlans = await this.list();

    let templates = allPlans.filter(
      (p) => p.coachId === EMPTY_GUID && p.isPublished
    );

    if (filters?.search) {
      const q = filters.search.toLowerCase();
      templates = templates.filter((p) =>
        p.name.toLowerCase().includes(q)
      );
    }

    return {
      items: templates,
      total: templates.length,
      page: 1,
      pageSize: templates.length,
      totalPages: 1,
      filters: {
        muscleGroups: [],
        equipment: [],
        difficulties: [],
        goals: [],
      },
    };
  },

  /* ----------------------------------
     CLIENT VIEW
     - Supports both legacy and future
  ---------------------------------- */
  async listForClient(
    clientId?: string
  ): Promise<ClientWorkoutPlan[]> {
    if (clientId) {
      // Legacy compatibility (if backend adds it later)
      return apiService.get<ClientWorkoutPlan[]>(
        `${V2_BASE}/client/${clientId}`
      );
    }

    // Canonical self-serve endpoint
    return apiService.get<ClientWorkoutPlan[]>(
      `${V2_BASE}/my`
    );
  },
};

export default workoutPlanService;
