import type { UserRole } from "@/types";

export type NavItem = {
  label: string;
  path: string;
  roles: UserRole[];
};

export const WORKOUT_PLANS_NAV: NavItem[] = [
  // ---------------- COACH ----------------
  {
    label: "My workout plans",
    path: "/workout-plans",
    roles: ["coach"],
  },
  {
    label: "Create workout plan",
    path: "/workout-plans/new",
    roles: ["coach"],
  },
  {
    label: "Explore templates",
    path: "/workout-templates",
    roles: ["coach"],
  },

  // ---------------- CLIENT ----------------
  {
    label: "My workouts",
    path: "/my-plan",
    roles: ["client"],
  },
  {
    label: "Explore programs",
    path: "/client/workout-templates",
    roles: ["client"],
  },
  {
    label: "My drafts",
    path: "/client/workout-drafts",
    roles: ["client"],
  },

  // ---------------- ADMIN ----------------
  {
    label: "Workout templates",
    path: "/admin/workout-templates",
    roles: ["admin"],
  },
];
