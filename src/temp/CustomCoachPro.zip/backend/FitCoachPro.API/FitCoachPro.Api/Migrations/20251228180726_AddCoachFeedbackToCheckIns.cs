﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FitCoachPro.Api.Migrations
{
    /// <inheritdoc />
    public partial class AddCoachFeedbackToCheckIns : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ClientNotes_ClientId_CoachId_CreatedAt",
                table: "ClientNotes");

            migrationBuilder.AddColumn<string>(
                name: "CoachActionItemsJson",
                table: "CheckIns",
                type: "nvarchar(4000)",
                maxLength: 4000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CoachFeedback",
                table: "CheckIns",
                type: "nvarchar(2000)",
                maxLength: 2000,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CoachActionItemsJson",
                table: "CheckIns");

            migrationBuilder.DropColumn(
                name: "CoachFeedback",
                table: "CheckIns");

            migrationBuilder.CreateIndex(
                name: "IX_ClientNotes_ClientId_CoachId_CreatedAt",
                table: "ClientNotes",
                columns: new[] { "ClientId", "CoachId", "CreatedAt" });
        }
    }
}
