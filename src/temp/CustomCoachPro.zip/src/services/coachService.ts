import apiService from "@/services/api";
import { API_ENDPOINTS } from "@/config/api";

export type CoachClientListItem = {
  id: string;
  email: string;
  displayName: string;
  startDate?: string;
  currentWeight?: number;
  targetWeight?: number;
  attentionReason?: string | null;

  // ✅ Step A (optional fields returned by backend)
  noteCount?: number;
  latestNotePreview?: string | null;
};

export type CoachClientDetail = {
  id: string;
  email: string;
  role: string;
  profile: {
    displayName: string;
    bio?: string | null;
    avatarUrl?: string | null;
    preferredUnitSystem?: string | null;
    startDate?: string | null;

    heightCm?: number | null;
    neckCm?: number | null;
    armsCm?: number | null;
    quadsCm?: number | null;
    hipsCm?: number | null;

    startWeight?: number | null;
    currentWeight?: number | null;
    targetWeight?: number | null;
  };
};

export type ClientNote = {
  id: string;
  clientId: string;
  coachId: string;
  content: string;
  createdAt: string;
  updatedAt?: string | null;
};

export type CreateClientNoteRequest = {
  content: string;
};

export type UpdateClientNoteRequest = {
  content: string;
};

export type CreateClientRequest = {
  email: string;
  displayName?: string;
  preferredUnitSystem?: string;
};

export type CreateClientResponse = {
  id: string;
  email: string;
};

export type UpdateClientRequest = {
  displayName?: string;
  bio?: string;
  avatarUrl?: string;
  preferredUnitSystem?: string;

  heightCm?: number;
  neckCm?: number;
  armsCm?: number;
  quadsCm?: number;
  hipsCm?: number;

  startWeight?: number;
  currentWeight?: number;
  targetWeight?: number;
};

const coachService = {
  /**
   * ✅ Canonical method name used by the service.
   */
  async listClients(): Promise<CoachClientListItem[]> {
    return apiService.get<CoachClientListItem[]>(API_ENDPOINTS.coach.clients);
  },

  /**
   * ✅ Backward-compatible alias:
   * Multiple pages call coachService.getClients() in the current UI code.
   * Keeping this avoids breaking clients list / dashboard / assign pages.
   */
  async getClients(): Promise<CoachClientListItem[]> {
    return coachService.listClients();
  },

  async searchClients(query: string): Promise<CoachClientListItem[]> {
    const q = encodeURIComponent(query);
    return apiService.get<CoachClientListItem[]>(`/coach/clients/search?q=${q}`);
  },

  async getClient(id: string): Promise<CoachClientDetail> {
    return apiService.get<CoachClientDetail>(API_ENDPOINTS.coach.clientById(id));
  },

  async createClient(req: CreateClientRequest): Promise<CreateClientResponse> {
    return apiService.post<CreateClientResponse>(API_ENDPOINTS.coach.clients, req);
  },

  async updateClient(id: string, req: UpdateClientRequest): Promise<CoachClientDetail> {
    return apiService.put<CoachClientDetail>(API_ENDPOINTS.coach.clientById(id), req);
  },

  // ===== Client Notes (Step A) =====
  async getClientNotes(clientId: string): Promise<ClientNote[]> {
    return apiService.get<ClientNote[]>(`/coach/clients/${clientId}/notes`);
  },

  async createClientNote(clientId: string, req: CreateClientNoteRequest): Promise<ClientNote> {
    return apiService.post<ClientNote>(`/coach/clients/${clientId}/notes`, req);
  },

  async updateClientNote(clientId: string, noteId: string, req: UpdateClientNoteRequest): Promise<ClientNote> {
    return apiService.put<ClientNote>(`/coach/clients/${clientId}/notes/${noteId}`, req);
  },

  async deleteClientNote(clientId: string, noteId: string): Promise<{ ok: boolean }> {
    return apiService.delete<{ ok: boolean }>(`/coach/clients/${clientId}/notes/${noteId}`);
  },
};

export default coachService;
