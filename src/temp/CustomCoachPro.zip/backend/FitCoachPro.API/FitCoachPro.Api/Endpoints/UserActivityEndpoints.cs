using System.Security.Claims;
using FitCoachPro.Api.Data;
using FitCoachPro.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FitCoachPro.Api.Endpoints;

public static class UserActivityEndpoints
{
    public static void MapUserActivityEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/activity")
                       .RequireAuthorization();

        group.MapGet("/workout-plan/last", async (
            ClaimsPrincipal user,
            AppDbContext db
        ) =>
        {
            var userId = user.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId is null) return Results.Unauthorized();

            var uid = Guid.Parse(userId);

            var activity = await db.UserLastActivities
                .AsNoTracking()
                .FirstOrDefaultAsync(x =>
                    x.UserId == uid &&
                    x.Domain == "workout-plan");

            if (activity is null)
                return Results.Ok(null);

            return Results.Ok(new
            {
                planId = activity.EntityId,
                planName = activity.EntityName,
                action = activity.Action,
                updatedAt = activity.UpdatedAtUtc
            });
        });

        group.MapPost("/workout-plan", async (
            ClaimsPrincipal user,
            AppDbContext db,
            UpdateLastWorkoutPlanRequest req
        ) =>
        {
            var userId = user.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId is null) return Results.Unauthorized();

            var uid = Guid.Parse(userId);

            var existing = await db.UserLastActivities
                .FirstOrDefaultAsync(x =>
                    x.UserId == uid &&
                    x.Domain == "workout-plan");

            if (existing is null)
            {
                db.UserLastActivities.Add(new UserLastActivity
                {
                    UserId = uid,
                    Domain = "workout-plan",
                    EntityId = req.PlanId,
                    EntityName = req.PlanName,
                    Action = req.Action
                });
            }
            else
            {
                existing.EntityId = req.PlanId;
                existing.EntityName = req.PlanName;
                existing.Action = req.Action;
                existing.UpdatedAtUtc = DateTime.UtcNow;
            }

            await db.SaveChangesAsync();
            return Results.Ok();
        });
    }

    public record UpdateLastWorkoutPlanRequest(
        Guid PlanId,
        string PlanName,
        string Action
    );
}
