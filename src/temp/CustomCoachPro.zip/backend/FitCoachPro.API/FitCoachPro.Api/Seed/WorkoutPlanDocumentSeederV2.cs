using System.Text.Json;
using FitCoachPro.Api.Data;
using FitCoachPro.Api.Models;
using FitCoachPro.Api.Models.WorkoutPlans;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;

namespace FitCoachPro.Api.Seed;

public static class WorkoutPlanDocumentSeederV2
{
    public static async Task SeedAsync(AppDbContext db, IWebHostEnvironment env)
    {
        var seedFilePath = Path.Combine(
            env.ContentRootPath,
            "SeedContent",
            "workoutPlans.json"
        );

        if (!File.Exists(seedFilePath))
            throw new FileNotFoundException(
                "Workout plan document seed file not found",
                seedFilePath
            );

        var json = await File.ReadAllTextAsync(seedFilePath);

        var documents = JsonSerializer.Deserialize<List<WorkoutPlanDocument>>(
            json,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
        );

        if (documents == null || documents.Count == 0)
            return;

        foreach (var doc in documents)
        {
            var name = doc.Meta.Name.Trim();

            // Prevent duplicates by NAME (system templates)
            var exists = await db.WorkoutPlanDocuments
                .AnyAsync(p => p.Name == name && p.CoachId == Guid.Empty);

            if (exists)
                continue;

            var entity = new WorkoutPlanEntity
            {
                Id = Guid.NewGuid(),
                CoachId = Guid.Empty,               // system-owned template
                Name = name,
                IsPublished = doc.Meta.IsPublished,
                DefinitionJson = JsonSerializer.Serialize(doc),
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            db.WorkoutPlanDocuments.Add(entity);
        }

        await db.SaveChangesAsync();
    }
}
