# FitCoachPro – Product Constitution

## 1. Product Type
FitCoachPro is a **two-sided fitness marketplace platform**:
- Coaches manage clients and programs
- Clients can self-serve without a coach
- Admins curate system quality

## 2. Core Roles
- Admin
- Coach
- Client

Each role has **distinct goals, UI surfaces, and permissions**.

## 3. Workout Plans – Canonical Model
Workout plans exist in three forms:
1. System Templates (Admin-owned)
2. Coach Plans (Coach-owned)
3. Assigned Plans (Client-bound, immutable source)

Clients never edit source plans.
All edits happen via copies.

## 4. UI Principle (Non-Negotiable)
- Same data, different surfaces
- No “one UI fits all roles”
- Destructive actions are centralized

## 5. Client Experience Rule
Clients must be able to:
- Explore programs
- Create personal plans
- Follow workouts
WITHOUT needing a coach.

## 6. Coach Experience Rule
Coaches must be able to:
- Reuse templates
- Customize freely
- Assign safely
WITHOUT risking system templates.

## 7. Admin Authority
Admins:
- Own system templates
- Control publish state
- Can see everything

## 8. Deviation Rule
If a feature conflicts with this constitution:
- The constitution wins
- Or it must be explicitly updated
