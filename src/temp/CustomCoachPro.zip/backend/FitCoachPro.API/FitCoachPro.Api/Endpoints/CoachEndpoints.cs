using System.Security.Claims;
using FitCoachPro.Api.Data;
using FitCoachPro.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace FitCoachPro.Api.Endpoints;

public static class CoachEndpoints
{
    public static void MapCoachEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/coach")
            .RequireAuthorization()
            .RequireAuthorization(new AuthorizeAttribute { Roles = "coach" });

        group.MapGet("/clients", async (ClaimsPrincipal principal, AppDbContext db) =>
        {
            var coachId = GetUserId(principal);
            if (coachId is null) return Results.Unauthorized();

            var clients = await db.CoachClients
                .Where(x => x.CoachId == coachId.Value &&
                            x.IsActive)
                .Join(db.Users.Include(u => u.Profile),
                    cc => cc.ClientId,
                    u => u.Id,
                    (cc, u) => new ClientListItem(
                        u.Id,
                        u.Email,
                        u.Profile!.DisplayName,
                        u.Profile!.StartDate,
                        u.Profile!.CurrentWeight,
                        u.Profile!.TargetWeight
                    ))
                .ToListAsync();

            var clientIds = clients.Select(c => c.Id).ToList();

            var checkIns = clientIds.Count == 0
                ? new List<CheckIn>()
                : await db.CheckIns
                    .Where(ci => clientIds.Contains(ci.ClientId))
                    .OrderByDescending(ci => ci.SubmittedAt)
                    .ToListAsync();

            // ✅ Step A: note count + latest note preview per client
            // ✅ Step A: note count + latest note preview per client
            var noteGroups = clientIds.Count == 0
                ? new Dictionary<Guid, (int Count, string? Latest)>()
                : await db.ClientNotes
                    .Where(n => n.CoachId == coachId.Value && clientIds.Contains(n.ClientId))
                    .OrderByDescending(n => n.UpdatedAt ?? n.CreatedAt)
                    .GroupBy(n => n.ClientId)
                    .Select(g => new
                    {
                        clientId = g.Key,
                        count = g.Count(),
                        latest = g.Select(x => x.Content).FirstOrDefault()
                    })
                    // ✅ IMPORTANT: force tuple element names
                    .ToDictionaryAsync(x => x.clientId, x => (Count: x.count, Latest: x.latest));

            var response = clients
                .Select(client =>
                {
                    var notes = noteGroups.TryGetValue(client.Id, out var tuple)
                        ? tuple
                        : (Count: 0, Latest: (string?)null);

                    return new
                    {
                        id = client.Id,
                        email = client.Email,
                        displayName = client.DisplayName,
                        startDate = client.StartDate,
                        currentWeight = client.CurrentWeight,
                        targetWeight = client.TargetWeight,
                        attentionReason = GetAttentionReason(client, checkIns),

                        // ✅ Step A
                        noteCount = notes.Count,
                        latestNotePreview = notes.Latest
                    };
                })
                .ToList();


            return Results.Ok(response);
        });

        group.MapGet("/clients/search", async (ClaimsPrincipal principal, AppDbContext db, string q) =>
        {
            var coachId = GetUserId(principal);
            if (coachId is null) return Results.Unauthorized();

            q = (q ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(q)) return Results.Ok(new List<object>());

            var like = $"%{q}%";

            var clients = await db.CoachClients
                .Where(x => x.CoachId == coachId.Value && x.IsActive)
                .Join(db.Users.Include(u => u.Profile),
                    cc => cc.ClientId,
                    u => u.Id,
                    (cc, u) => u)
                .Where(u =>
                    EF.Functions.Like(u.Email, like) ||
                    EF.Functions.Like(u.Profile!.DisplayName, like) ||
                    db.ClientNotes.Any(n =>
                        n.CoachId == coachId.Value &&
                        n.ClientId == u.Id &&
                        EF.Functions.Like(n.Content, like)))
                .Select(u => new ClientListItem(
                    u.Id,
                    u.Email,
                    u.Profile!.DisplayName,
                    u.Profile!.StartDate,
                    u.Profile!.CurrentWeight,
                    u.Profile!.TargetWeight
                ))
                .ToListAsync();

            var clientIds = clients.Select(c => c.Id).ToList();

            var checkIns = clientIds.Count == 0
                ? new List<CheckIn>()
                : await db.CheckIns
                    .Where(ci => clientIds.Contains(ci.ClientId))
                    .OrderByDescending(ci => ci.SubmittedAt)
                    .ToListAsync();

            var noteGroups = clientIds.Count == 0
                ? new Dictionary<Guid, (int Count, string? Latest)>()
                : await db.ClientNotes
                    .Where(n => n.CoachId == coachId.Value && clientIds.Contains(n.ClientId))
                    .OrderByDescending(n => n.UpdatedAt ?? n.CreatedAt)
                    .GroupBy(n => n.ClientId)
                    .Select(g => new
                    {
                        clientId = g.Key,
                        count = g.Count(),
                        latest = g.Select(x => x.Content).FirstOrDefault()
                    })
                    // ✅ IMPORTANT: force tuple element names
                    .ToDictionaryAsync(x => x.clientId, x => (Count: x.count, Latest: x.latest));

            var response = clients
                .Select(client =>
                {
                    var notes = noteGroups.TryGetValue(client.Id, out var tuple)
                        ? tuple
                        : (Count: 0, Latest: (string?)null);

                    return new
                    {
                        id = client.Id,
                        email = client.Email,
                        displayName = client.DisplayName,
                        startDate = client.StartDate,
                        currentWeight = client.CurrentWeight,
                        targetWeight = client.TargetWeight,
                        attentionReason = GetAttentionReason(client, checkIns),

                        noteCount = notes.Count,
                        latestNotePreview = notes.Latest
                    };
                })
                .ToList();


            return Results.Ok(response);
        });

        group.MapGet("/clients/{id:guid}", async (ClaimsPrincipal principal, AppDbContext db, Guid id) =>
        {
            var coachId = GetUserId(principal);
            if (coachId is null) return Results.Unauthorized();

            var mapped = await db.CoachClients.AnyAsync(x => x.CoachId == coachId.Value && x.ClientId == id && x.IsActive);
            if (!mapped) return Results.NotFound(new { message = "Client not assigned to you" });

            var client = await db.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == id);
            if (client is null) return Results.NotFound();

            return Results.Ok(new
            {
                id = client.Id,
                email = client.Email,
                role = client.Role,
                profile = new
                {
                    displayName = client.Profile?.DisplayName ?? client.Email,
                    bio = client.Profile?.Bio,
                    avatarUrl = client.Profile?.AvatarUrl,
                    preferredUnitSystem = client.Profile?.PreferredUnitSystem ?? "imperial",
                    startDate = client.Profile?.StartDate,

                    heightCm = client.Profile?.HeightCm,
                    neckCm = client.Profile?.NeckCm,
                    armsCm = client.Profile?.ArmsCm,
                    quadsCm = client.Profile?.QuadsCm,
                    hipsCm = client.Profile?.HipsCm,
                    startWeight = client.Profile?.StartWeight,
                    currentWeight = client.Profile?.CurrentWeight,
                    targetWeight = client.Profile?.TargetWeight
                }
            });
        });

        // ===== Client Notes =====
        group.MapGet("/clients/{id:guid}/notes", async (ClaimsPrincipal principal, AppDbContext db, Guid id) =>
        {
            var coachId = GetUserId(principal);
            if (coachId is null) return Results.Unauthorized();

            var mapped = await db.CoachClients.AnyAsync(x => x.CoachId == coachId.Value && x.ClientId == id && x.IsActive);
            if (!mapped) return Results.NotFound(new { message = "Client not assigned to you" });

            var notes = await db.ClientNotes
                .Where(n => n.ClientId == id && n.CoachId == coachId.Value)
                .OrderByDescending(n => n.CreatedAt)
                .Select(n => new
                {
                    id = n.Id,
                    clientId = n.ClientId,
                    coachId = n.CoachId,
                    content = n.Content,
                    createdAt = n.CreatedAt,
                    updatedAt = n.UpdatedAt
                })
                .ToListAsync();

            return Results.Ok(notes);
        });

        group.MapPost("/clients/{id:guid}/notes", async (ClaimsPrincipal principal, AppDbContext db, Guid id, CreateClientNoteRequest req) =>
        {
            var coachId = GetUserId(principal);
            if (coachId is null) return Results.Unauthorized();

            var mapped = await db.CoachClients.AnyAsync(x => x.CoachId == coachId.Value && x.ClientId == id && x.IsActive);
            if (!mapped) return Results.NotFound(new { message = "Client not assigned to you" });

            if (string.IsNullOrWhiteSpace(req.Content))
                return Results.BadRequest(new { message = "Content is required" });

            var note = new ClientNote
            {
                ClientId = id,
                CoachId = coachId.Value,
                Content = req.Content.Trim(),
                CreatedAt = DateTime.UtcNow
            };

            db.ClientNotes.Add(note);
            await db.SaveChangesAsync();

            return Results.Ok(new
            {
                id = note.Id,
                clientId = note.ClientId,
                coachId = note.CoachId,
                content = note.Content,
                createdAt = note.CreatedAt,
                updatedAt = note.UpdatedAt
            });
        });

        group.MapPut("/clients/{id:guid}/notes/{noteId:guid}", async (ClaimsPrincipal principal, AppDbContext db, Guid id, Guid noteId, UpdateClientNoteRequest req) =>
        {
            var coachId = GetUserId(principal);
            if (coachId is null) return Results.Unauthorized();

            var mapped = await db.CoachClients.AnyAsync(x => x.CoachId == coachId.Value && x.ClientId == id && x.IsActive);
            if (!mapped) return Results.NotFound(new { message = "Client not assigned to you" });

            var note = await db.ClientNotes.FirstOrDefaultAsync(n => n.Id == noteId && n.ClientId == id && n.CoachId == coachId.Value);
            if (note is null) return Results.NotFound(new { message = "Note not found" });

            if (string.IsNullOrWhiteSpace(req.Content))
                return Results.BadRequest(new { message = "Content is required" });

            note.Content = req.Content.Trim();
            note.UpdatedAt = DateTime.UtcNow;

            await db.SaveChangesAsync();

            return Results.Ok(new
            {
                id = note.Id,
                clientId = note.ClientId,
                coachId = note.CoachId,
                content = note.Content,
                createdAt = note.CreatedAt,
                updatedAt = note.UpdatedAt
            });
        });

        group.MapDelete("/clients/{id:guid}/notes/{noteId:guid}", async (ClaimsPrincipal principal, AppDbContext db, Guid id, Guid noteId) =>
        {
            var coachId = GetUserId(principal);
            if (coachId is null) return Results.Unauthorized();

            var mapped = await db.CoachClients.AnyAsync(x => x.CoachId == coachId.Value && x.ClientId == id && x.IsActive);
            if (!mapped) return Results.NotFound(new { message = "Client not assigned to you" });

            var note = await db.ClientNotes.FirstOrDefaultAsync(n => n.Id == noteId && n.ClientId == id && n.CoachId == coachId.Value);
            if (note is null) return Results.NotFound(new { message = "Note not found" });

            db.ClientNotes.Remove(note);
            await db.SaveChangesAsync();

            return Results.Ok(new { ok = true });
        });

        group.MapPost("/clients", async (ClaimsPrincipal principal, AppDbContext db, CreateClientRequest req) =>
        {
            var coachId = GetUserId(principal);
            if (coachId is null) return Results.Unauthorized();

            // basic validation
            if (string.IsNullOrWhiteSpace(req.Email))
                return Results.BadRequest(new { message = "Email is required" });

            var email = req.Email.Trim().ToLowerInvariant();

            // create user if not exists
            var existing = await db.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Email == email);

            User client;
            if (existing is null)
            {
                client = new User
                {
                    Email = email,
                    Role = "client",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("password")
                };

                client.Profile = new UserProfile
                {
                    UserId = client.Id,
                    DisplayName = req.DisplayName ?? email.Split('@')[0],
                    PreferredUnitSystem = req.PreferredUnitSystem ?? "imperial",
                    StartDate = DateTime.UtcNow
                };

                db.Users.Add(client);
            }
            else
            {
                client = existing;
            }

            // map coach to client
            var mappingExists = await db.CoachClients.AnyAsync(x => x.CoachId == coachId.Value && x.ClientId == client.Id);
            if (!mappingExists)
            {
                db.CoachClients.Add(new CoachClient
                {
                    CoachId = coachId.Value,
                    ClientId = client.Id,
                    IsActive = true
                });
            }

            await db.SaveChangesAsync();

            return Results.Ok(new
            {
                id = client.Id,
                email = client.Email
            });
        });

        group.MapPut("/clients/{id:guid}", async (ClaimsPrincipal principal, AppDbContext db, Guid id, UpdateClientRequest req) =>
        {
            var coachId = GetUserId(principal);
            if (coachId is null) return Results.Unauthorized();

            var mapped = await db.CoachClients.AnyAsync(x => x.CoachId == coachId.Value && x.ClientId == id && x.IsActive);
            if (!mapped) return Results.NotFound(new { message = "Client not assigned to you" });

            var client = await db.Users.Include(u => u.Profile).FirstOrDefaultAsync(u => u.Id == id);
            if (client is null) return Results.NotFound();

            client.Profile ??= new UserProfile { UserId = client.Id };

            client.Profile.DisplayName = req.DisplayName ?? client.Profile.DisplayName;
            client.Profile.Bio = req.Bio ?? client.Profile.Bio;
            client.Profile.AvatarUrl = req.AvatarUrl ?? client.Profile.AvatarUrl;
            client.Profile.PreferredUnitSystem = req.PreferredUnitSystem ?? client.Profile.PreferredUnitSystem;

            client.Profile.HeightCm = req.HeightCm ?? client.Profile.HeightCm;
            client.Profile.NeckCm = req.NeckCm ?? client.Profile.NeckCm;
            client.Profile.ArmsCm = req.ArmsCm ?? client.Profile.ArmsCm;
            client.Profile.QuadsCm = req.QuadsCm ?? client.Profile.QuadsCm;
            client.Profile.HipsCm = req.HipsCm ?? client.Profile.HipsCm;

            client.Profile.StartWeight = req.StartWeight ?? client.Profile.StartWeight;
            client.Profile.CurrentWeight = req.CurrentWeight ?? client.Profile.CurrentWeight;
            client.Profile.TargetWeight = req.TargetWeight ?? client.Profile.TargetWeight;

            await db.SaveChangesAsync();

            return Results.Ok(new
            {
                id = client.Id,
                email = client.Email,
                role = client.Role,
                profile = new
                {
                    displayName = client.Profile.DisplayName ?? client.Email,
                    bio = client.Profile.Bio,
                    avatarUrl = client.Profile.AvatarUrl,
                    preferredUnitSystem = client.Profile.PreferredUnitSystem ?? "imperial",
                    startDate = client.Profile.StartDate,

                    heightCm = client.Profile.HeightCm,
                    neckCm = client.Profile.NeckCm,
                    armsCm = client.Profile.ArmsCm,
                    quadsCm = client.Profile.QuadsCm,
                    hipsCm = client.Profile.HipsCm,
                    startWeight = client.Profile.StartWeight,
                    currentWeight = client.Profile.CurrentWeight,
                    targetWeight = client.Profile.TargetWeight
                }
            });
        });

        group.MapDelete("/clients/{id:guid}", async (ClaimsPrincipal principal, AppDbContext db, Guid id) =>
        {
            var coachId = GetUserId(principal);
            if (coachId is null) return Results.Unauthorized();

            var mapping = await db.CoachClients.FirstOrDefaultAsync(x => x.CoachId == coachId.Value && x.ClientId == id);
            if (mapping is null) return Results.NotFound();

            mapping.IsActive = false;
            await db.SaveChangesAsync();

            return Results.Ok(new { ok = true });
        });
    }

    private static Guid? GetUserId(ClaimsPrincipal principal)
    {
        var id = principal.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.TryParse(id, out var guid) ? guid : null;
    }

    private static string? GetAttentionReason(ClientListItem client, List<CheckIn> allCheckIns)
    {
        // Find last weight check-in for the client
        var last = allCheckIns
            .Where(ci => ci.ClientId == client.Id && ci.Type == CheckInType.Weight)
            .OrderByDescending(ci => ci.SubmittedAt)
            .FirstOrDefault();

        if (last is null)
            return "No check-ins yet";

        var days = (DateTime.UtcNow - last.SubmittedAt).TotalDays;

        if (days >= 7)
            return "Overdue (7+ days)";

        // If target exists and is close to current maybe
        if (client.TargetWeight.HasValue && client.CurrentWeight.HasValue)
        {
            var diff = Math.Abs((double)(client.CurrentWeight.Value - client.TargetWeight.Value));
            if (diff <= 1.0)
                return "Near goal";
        }

        return null;
    }

    private record CreateClientRequest(
        string Email,
        string? DisplayName,
        string? PreferredUnitSystem
    );

    private record UpdateClientRequest(
        string? DisplayName,
        string? Bio,
        string? AvatarUrl,
        decimal? HeightCm,
        decimal? NeckCm,
        decimal? ArmsCm,
        decimal? QuadsCm,
        decimal? HipsCm,
        decimal? StartWeight,
        decimal? CurrentWeight,
        decimal? TargetWeight,
        string? PreferredUnitSystem
    );

    private record CreateClientNoteRequest(string Content);
    private record UpdateClientNoteRequest(string Content);

    private record ClientListItem(
        Guid Id,
        string Email,
        string DisplayName,
        DateTime? StartDate,
        decimal? CurrentWeight,
        decimal? TargetWeight
    );
}
