import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";

import workoutService from "@/services/workoutService";
import clientService from "@/services/clientService";

interface Props {
  planId: string | null;
  open: boolean;
  onClose: () => void;
  onAssigned?: () => void;
}

export function AssignWorkoutPlanModal({
  planId,
  open,
  onClose,
  onAssigned,
}: Props) {
  const [clientId, setClientId] = useState<string>("");

  const { data: clients = [], isLoading } = useQuery({
    queryKey: ["clients"],
    queryFn: clientService.getAll,
    enabled: open,
  });

  async function handleAssign() {
    if (!planId || !clientId) return;

    await workoutService.assignToClient(planId, clientId);

    onAssigned?.();
    onClose();
    setClientId("");
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Assign Workout Plan</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Select value={clientId} onValueChange={setClientId}>
            <SelectTrigger>
              <SelectValue placeholder="Select a client" />
            </SelectTrigger>
            <SelectContent>
              {clients.map((client) => (
                <SelectItem key={client.id} value={client.id}>
                  {client.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleAssign} disabled={!clientId}>
              Assign
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
