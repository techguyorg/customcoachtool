using System.Security.Claims;
using System.Text.Json;
using FitCoachPro.Api.Data;
using FitCoachPro.Api.Models;
using FitCoachPro.Api.Models.WorkoutPlans;
using FitCoachPro.Api.Models.Workouts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;

namespace FitCoachPro.Api.Endpoints;

public static class WorkoutPlanV2Endpoints
{
    public static void MapWorkoutPlanV2Endpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/v2/workout-plans")
                       .RequireAuthorization();

        /* ============================
           LIST – ALL PLANS
           ============================ */
        group.MapGet("/", async (ClaimsPrincipal user, AppDbContext db) =>
        {
            var userId = GetUserId(user);
            if (userId == null) return Results.Unauthorized();

            IQueryable<WorkoutPlanEntity> query = db.WorkoutPlanDocuments;

            if (!IsAdmin(user))
            {
                query = query.Where(p =>
                    p.CoachId == Guid.Empty || p.CoachId == userId
                );
            }

            var plans = await query
                .OrderByDescending(p => p.UpdatedAt)
                .ToListAsync();

           var result = plans.Select(p =>
            {
                var doc = JsonSerializer.Deserialize<WorkoutPlanDocument>(
                    p.DefinitionJson
                );

                return new
                {
                    p.Id,
                    p.CoachId,
                    Name = doc!.Meta.Name,
                    Description = doc.Meta.Description,
                    DurationWeeks = doc.Meta.DurationWeeks,
                    IsPublished = doc.Meta.IsPublished,
                    Days = doc.Days,
                    p.CreatedAt,
                    p.UpdatedAt
                };
            });

            return Results.Ok(result);


        });

        /* ============================
           GET ONE
           ============================ */
        group.MapGet("/{id:guid}", async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid id) =>
        {
            var userId = GetUserId(user);
            if (userId == null) return Results.Unauthorized();

            var entity = await db.WorkoutPlanDocuments
                .FirstOrDefaultAsync(p => p.Id == id);

            if (entity == null)
                return Results.NotFound();

            // Authorization
            if (!IsAdmin(user) &&
                entity.CoachId != userId &&
                entity.CoachId != Guid.Empty)
            {
                return Results.Forbid();
            }


            var doc = JsonSerializer.Deserialize<WorkoutPlanDocument>(
                entity.DefinitionJson
            );

            return Results.Ok(doc);
        });

        /* ============================
           CREATE (COACH ONLY)
           ============================ */
        group.MapPost("/", [Authorize(Roles = UserRole.Coach)] async (
            ClaimsPrincipal user,
            AppDbContext db,
            WorkoutPlanDocument document) =>
        {
            var coachId = GetUserId(user);
            if (coachId == null) return Results.Unauthorized();

            // HARD VALIDATION – plans MUST have days
            if (document.Days == null || document.Days.Count == 0)
                return Results.BadRequest("Workout plan must contain at least one day.");

            var entity = new WorkoutPlanEntity
            {
                Id = Guid.NewGuid(),
                CoachId = coachId.Value,
                Name = document.Meta.Name,
                IsPublished = document.Meta.IsPublished,
                DefinitionJson = JsonSerializer.Serialize(document),
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            db.WorkoutPlanDocuments.Add(entity);
            await db.SaveChangesAsync();

            return Results.Ok(new { id = entity.Id });
        });

        /* ============================
           UPDATE (COACH OR ADMIN)
           ============================ */
        group.MapPut("/{id:guid}", [Authorize(Roles = $"{UserRole.Coach},{UserRole.Admin}")] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid id,
            WorkoutPlanDocument document) =>
        {
            var userId = GetUserId(user);
            if (userId == null) return Results.Unauthorized();

            var entity = await db.WorkoutPlanDocuments
                .FirstOrDefaultAsync(p => p.Id == id);

            if (entity == null)
                return Results.NotFound();

            if (!IsAdmin(user) && entity.CoachId != userId)
                return Results.Forbid();

            if (document.Days == null || document.Days.Count == 0)
                return Results.BadRequest("Workout plan must contain at least one day.");

            entity.Name = document.Meta.Name;
            entity.IsPublished = document.Meta.IsPublished;
            entity.DefinitionJson = JsonSerializer.Serialize(document);
            entity.UpdatedAt = DateTime.UtcNow;

            await db.SaveChangesAsync();
            return Results.Ok();
        });

        /* ============================
        ASSIGN TO CLIENT (COACH ONLY)
        ============================ */
        group.MapPost("/{id:guid}/assign", [Authorize(Roles = UserRole.Coach)] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid id,
            Guid clientId) =>
        {
            var coachId = GetUserId(user);
            if (coachId == null) return Results.Unauthorized();

            var template = await db.WorkoutPlanDocuments
                .FirstOrDefaultAsync(p => p.Id == id);

            if (template == null)
                return Results.NotFound("Workout template not found.");

            if (template.CoachId != coachId && template.CoachId != Guid.Empty)
                return Results.Forbid();

            if (!template.IsPublished)
                return Results.BadRequest("Workout plan must be published before assignment.");

            var assigned = new AssignedWorkoutPlanEntity
            {
                Id = Guid.NewGuid(),
                ClientId = clientId,
                CoachId = coachId.Value,
                TemplatePlanId = template.Id,
                DefinitionJson = template.DefinitionJson,
                AssignedAt = DateTime.UtcNow,
                StartsOn = DateTime.UtcNow.Date,
                IsActive = true
            };

            db.AssignedWorkoutPlans.Add(assigned);
            await db.SaveChangesAsync();

            return Results.Ok(new { assignedId = assigned.Id });
        });


        /* ============================
           DELETE (COACH OR ADMIN)
           ============================ */
        group.MapDelete("/{id:guid}", [Authorize(Roles = $"{UserRole.Coach},{UserRole.Admin}")] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid id) =>
        {
            var userId = GetUserId(user);
            if (userId == null) return Results.Unauthorized();

            var entity = await db.WorkoutPlanDocuments
                .FirstOrDefaultAsync(p => p.Id == id);

            if (entity == null)
                return Results.NotFound();

            if (!IsAdmin(user) && entity.CoachId != userId)
                return Results.Forbid();

            db.WorkoutPlanDocuments.Remove(entity);
            await db.SaveChangesAsync();

            return Results.Ok();
        });

    /* ============================
    CLIENT – MY ASSIGNED WORKOUTS
    ============================ */
    group.MapGet("/my", [Authorize(Roles = UserRole.Client)] async (
        ClaimsPrincipal user,
        AppDbContext db) =>
    {
        var clientId = GetUserId(user);
        if (clientId == null)
            return Results.Unauthorized();

        var plans = await db.AssignedWorkoutPlans
            .Where(p => p.ClientId == clientId && p.IsActive)
            .OrderByDescending(p => p.AssignedAt)
            .ToListAsync();

        var result = plans.Select(p => new
        {
            p.Id,
            p.TemplatePlanId,
            p.AssignedAt,
            p.StartsOn,
            Definition = JsonSerializer.Deserialize<WorkoutPlanDocument>(p.DefinitionJson)
        });

        return Results.Ok(result);

    });

    /* ============================
    COACH – ASSIGNED PLANS (READ)
    ============================ */
    group.MapGet("/assigned", [Authorize(Roles = UserRole.Coach)] async (
        ClaimsPrincipal user,
        AppDbContext db) =>
    {
        var coachId = GetUserId(user);
        if (coachId == null)
            return Results.Unauthorized();

        // Fetch first (SQL-safe)
        var assigned = await db.AssignedWorkoutPlans
            .Where(p => p.CoachId == coachId)
            .OrderByDescending(p => p.AssignedAt)
            .ToListAsync();

        // Materialize + deserialize in memory
        var result = assigned.Select(p => new
        {
            AssignedPlanId = p.Id,
            p.ClientId,
            p.TemplatePlanId,
            p.AssignedAt,
            p.StartsOn,
            p.IsActive,
            Definition = JsonSerializer.Deserialize<WorkoutPlanDocument>(p.DefinitionJson)
        });

        return Results.Ok(result);
    });

    /* ============================
    CLIENT – START WORKOUT SESSION
    ============================ */
    group.MapPost("/assigned/{assignedId:guid}/sessions/start",
        [Authorize(Roles = UserRole.Client)] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid assignedId,
            int? planDayOrder) =>
    {
        var clientId = GetUserId(user);
        if (clientId == null)
            return Results.Unauthorized();

        var assigned = await db.AssignedWorkoutPlans
            .FirstOrDefaultAsync(p => p.Id == assignedId && p.ClientId == clientId);

        if (assigned == null)
            return Results.NotFound("Assigned workout plan not found.");

        var session = new WorkoutSessionEntity
        {
            Id = Guid.NewGuid(),
            ClientId = clientId.Value,
            CoachId = assigned.CoachId,
            AssignedWorkoutPlanId = assigned.Id,
            PlanDayOrder = planDayOrder,
            PerformedWorkoutJson = assigned.DefinitionJson, // initial snapshot
            StartedAt = DateTime.UtcNow,
            IsCompleted = false
        };

        db.WorkoutSessions.Add(session);
        await db.SaveChangesAsync();

        return Results.Ok(new { sessionId = session.Id });
    });

    /* ============================
    CLIENT – COMPLETE WORKOUT SESSION
    ============================ */
    group.MapPost("/sessions/{sessionId:guid}/complete",
        [Authorize(Roles = UserRole.Client)] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid sessionId,
            WorkoutPlanDocument performedWorkout) =>
    {
        var clientId = GetUserId(user);
        if (clientId == null)
            return Results.Unauthorized();

        var session = await db.WorkoutSessions
            .FirstOrDefaultAsync(s => s.Id == sessionId && s.ClientId == clientId);

        if (session == null)
            return Results.NotFound("Workout session not found.");

        if (session.IsCompleted)
            return Results.BadRequest("Session already completed.");

        if (session.EndedAt != null)
            return Results.BadRequest("Session already ended.");

        session.PerformedWorkoutJson = JsonSerializer.Serialize(performedWorkout);
        session.IsCompleted = true;
        session.EndedAt = DateTime.UtcNow;

        await db.SaveChangesAsync();

        return Results.Ok();
    });

    /* ============================
    WORKOUT SESSION HISTORY
    ============================ */
    group.MapGet("/sessions",
        [Authorize(Roles = $"{UserRole.Client},{UserRole.Coach}")] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid? assignedPlanId) =>
    {
        var userId = GetUserId(user);
        if (userId == null)
            return Results.Unauthorized();

        IQueryable<WorkoutSessionEntity> query = db.WorkoutSessions;

        if (user.IsInRole(UserRole.Client))
            query = query.Where(s => s.ClientId == userId);
        else
            query = query.Where(s => s.CoachId == userId);

        if (assignedPlanId.HasValue)
            query = query.Where(s => s.AssignedWorkoutPlanId == assignedPlanId);

        var sessions = await query
            .OrderByDescending(s => s.StartedAt)
            .ToListAsync();

        var result = sessions.Select(s => new
        {
            s.Id,
            s.AssignedWorkoutPlanId,
            s.PlanDayOrder,
            s.StartedAt,
            s.EndedAt,
            s.IsCompleted,
            PerformedWorkout = JsonSerializer.Deserialize<WorkoutPlanDocument>(s.PerformedWorkoutJson)
        });

        return Results.Ok(result);
    });

    /* ============================
    CLIENT – LOG EXERCISE SET
    ============================ */
    group.MapPost("/sessions/{sessionId:guid}/log",
        [Authorize(Roles = UserRole.Client)] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid sessionId,
            WorkoutExerciseLogEntity log) =>
    {
        var clientId = GetUserId(user);
        if (clientId == null)
            return Results.Unauthorized();

        var session = await db.WorkoutSessions
            .FirstOrDefaultAsync(s => s.Id == sessionId && s.ClientId == clientId);

        if (session == null)
            return Results.NotFound("Workout session not found.");

        // -------- VALIDATION --------
        if (log.SetNumber <= 0)
            return Results.BadRequest("SetNumber must be greater than zero.");

        if (log.Rpe.HasValue && (log.Rpe < 1 || log.Rpe > 10))
            return Results.BadRequest("RPE must be between 1 and 10.");

        if (log.Weight.HasValue && log.Weight < 0)
            return Results.BadRequest("Weight cannot be negative.");

        if (log.RepsPerformed.HasValue && log.RepsPerformed < 0)
            return Results.BadRequest("Reps cannot be negative.");

        if (string.IsNullOrWhiteSpace(log.ExerciseName))
            return Results.BadRequest("ExerciseName is required.");

        // -------- DUPLICATE PROTECTION --------
        var duplicateExists = await db.WorkoutExerciseLogs.AnyAsync(l =>
            l.WorkoutSessionId == session.Id &&
            l.DayOrder == log.DayOrder &&
            l.ExerciseOrder == log.ExerciseOrder &&
            l.SetNumber == log.SetNumber);

        if (duplicateExists)
            return Results.BadRequest("This set has already been logged.");

        log.Id = Guid.NewGuid();
        log.WorkoutSessionId = session.Id;
        log.ClientId = session.ClientId;
        log.CoachId = session.CoachId;
        log.LoggedAt = DateTime.UtcNow;

        db.WorkoutExerciseLogs.Add(log);
        await db.SaveChangesAsync();

        return Results.Ok(new { logId = log.Id });
    });

    /* ============================
    EXERCISE LOGS (READ)
    ============================ */
    group.MapGet("/sessions/{sessionId:guid}/logs",
        [Authorize(Roles = $"{UserRole.Client},{UserRole.Coach}")] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid sessionId) =>
    {
        var userId = GetUserId(user);
        if (userId == null)
            return Results.Unauthorized();

        IQueryable<WorkoutExerciseLogEntity> query =
            db.WorkoutExerciseLogs.Where(l => l.WorkoutSessionId == sessionId);

        if (user.IsInRole(UserRole.Client))
            query = query.Where(l => l.ClientId == userId);
        else
            query = query.Where(l => l.CoachId == userId);

        var logs = await query
            .OrderBy(l => l.DayOrder)
            .ThenBy(l => l.ExerciseOrder)
            .ThenBy(l => l.SetNumber)
            .ToListAsync();

        return Results.Ok(logs);
    });

    /* ============================
    COACH – ADD FEEDBACK
    ============================ */
    group.MapPost("/feedback",
        [Authorize(Roles = UserRole.Coach)] async (
            ClaimsPrincipal user,
            AppDbContext db,
            WorkoutCoachFeedbackEntity feedback) =>
    {
        var coachId = GetUserId(user);
        if (coachId == null)
            return Results.Unauthorized();

        // Basic validation
        if (feedback.WorkoutSessionId == null && feedback.WorkoutExerciseLogId == null)
            return Results.BadRequest("Feedback must target a session or an exercise log.");

        if (string.IsNullOrWhiteSpace(feedback.Comment))
            return Results.BadRequest("Comment cannot be empty.");

        feedback.Id = Guid.NewGuid();
        feedback.CoachId = coachId.Value;
        feedback.CreatedAt = DateTime.UtcNow;

        // Ensure coach owns the data they are commenting on
        if (feedback.WorkoutSessionId.HasValue)
        {
            var session = await db.WorkoutSessions
                .FirstOrDefaultAsync(s =>
                    s.Id == feedback.WorkoutSessionId &&
                    s.CoachId == coachId);

            if (session == null)
                return Results.Forbid();

            feedback.ClientId = session.ClientId;
        }

        if (feedback.WorkoutExerciseLogId.HasValue)
        {
            var log = await db.WorkoutExerciseLogs
                .FirstOrDefaultAsync(l =>
                    l.Id == feedback.WorkoutExerciseLogId &&
                    l.CoachId == coachId);

            if (log == null)
                return Results.Forbid();

            feedback.ClientId = log.ClientId;
        }

        db.WorkoutCoachFeedbacks.Add(feedback);
        await db.SaveChangesAsync();

        return Results.Ok(new { feedbackId = feedback.Id });
    });

    /* ============================
    FEEDBACK – READ
    ============================ */
    group.MapGet("/feedback",
        [Authorize(Roles = $"{UserRole.Client},{UserRole.Coach}")] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid? sessionId,
            Guid? exerciseLogId) =>
    {
        var userId = GetUserId(user);
        if (userId == null)
            return Results.Unauthorized();

        IQueryable<WorkoutCoachFeedbackEntity> query = db.WorkoutCoachFeedbacks;

        if (sessionId.HasValue)
            query = query.Where(f => f.WorkoutSessionId == sessionId);

        if (exerciseLogId.HasValue)
            query = query.Where(f => f.WorkoutExerciseLogId == exerciseLogId);

        if (user.IsInRole(UserRole.Client))
            query = query.Where(f => f.ClientId == userId);
        else
            query = query.Where(f => f.CoachId == userId);

        var feedback = await query
            .OrderByDescending(f => f.CreatedAt)
            .ToListAsync();

        return Results.Ok(feedback);
    });

    /* ============================
    ANALYTICS – CLIENT ADHERENCE
    ============================ */
    group.MapGet("/analytics/adherence",
        [Authorize(Roles = $"{UserRole.Client},{UserRole.Coach}")] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid? clientId,
            DateTime? from,
            DateTime? to) =>
    {
        var userId = GetUserId(user);
        if (userId == null)
            return Results.Unauthorized();

        // Resolve client
        Guid resolvedClientId;

        if (user.IsInRole(UserRole.Client))
        {
            resolvedClientId = userId.Value;
        }
        else
        {
            if (!clientId.HasValue)
                return Results.BadRequest("clientId is required for coach.");

            resolvedClientId = clientId.Value;
        }

        var start = from ?? DateTime.UtcNow.AddDays(-30);
        var end = to ?? DateTime.UtcNow;

        var sessions = await db.WorkoutSessions
            .Where(s =>
                s.ClientId == resolvedClientId &&
                s.StartedAt >= start &&
                s.StartedAt <= end)
            .ToListAsync();

        var completed = sessions.Count(s => s.IsCompleted);
        var abandoned = sessions.Count(s => !s.IsCompleted);

        return Results.Ok(new
        {
            ClientId = resolvedClientId,
            Period = new { From = start, To = end },
            TotalSessions = sessions.Count,
            CompletedSessions = completed,
            AbandonedSessions = abandoned,
            CompletionRate = sessions.Count == 0
                ? 0
                : Math.Round((double)completed / sessions.Count * 100, 2)
        });
    });

    /* ============================
    ANALYTICS – TRAINING VOLUME
    ============================ */
    group.MapGet("/analytics/volume",
        [Authorize(Roles = $"{UserRole.Client},{UserRole.Coach}")] async (
            ClaimsPrincipal user,
            AppDbContext db,
            Guid? clientId,
            DateTime? from,
            DateTime? to) =>
    {
        var userId = GetUserId(user);
        if (userId == null)
            return Results.Unauthorized();

        Guid resolvedClientId;

        if (user.IsInRole(UserRole.Client))
            resolvedClientId = userId.Value;
        else
        {
            if (!clientId.HasValue)
                return Results.BadRequest("clientId is required for coach.");

            resolvedClientId = clientId.Value;
        }

        var start = from ?? DateTime.UtcNow.AddDays(-30);
        var end = to ?? DateTime.UtcNow;

        var logs = await db.WorkoutExerciseLogs
            .Where(l =>
                l.ClientId == resolvedClientId &&
                l.LoggedAt >= start &&
                l.LoggedAt <= end &&
                l.Weight.HasValue &&
                l.RepsPerformed.HasValue)
            .ToListAsync();

        var totalVolume = logs.Sum(l => l.Weight!.Value * l.RepsPerformed!.Value);

        var byExercise = logs
            .GroupBy(l => l.ExerciseName)
            .Select(g => new
            {
                Exercise = g.Key,
                Volume = g.Sum(x => x.Weight!.Value * x.RepsPerformed!.Value)
            })
            .OrderByDescending(x => x.Volume);

        return Results.Ok(new
        {
            ClientId = resolvedClientId,
            Period = new { From = start, To = end },
            TotalVolume = totalVolume,
            ByExercise = byExercise
        });
    });

    /* ============================
    ANALYTICS – COACH OVERVIEW
    ============================ */
    group.MapGet("/analytics/coach-overview",
        [Authorize(Roles = UserRole.Coach)] async (
            ClaimsPrincipal user,
            AppDbContext db) =>
    {
        var coachId = GetUserId(user);
        if (coachId == null)
            return Results.Unauthorized();

        var sessions = await db.WorkoutSessions
            .Where(s => s.CoachId == coachId)
            .ToListAsync();

        var grouped = sessions
            .GroupBy(s => s.ClientId)
            .Select(g => new
            {
                ClientId = g.Key,
                TotalSessions = g.Count(),
                Completed = g.Count(s => s.IsCompleted),
                CompletionRate = g.Count() == 0
                    ? 0
                    : Math.Round(
                        (double)g.Count(s => s.IsCompleted) / g.Count() * 100, 2)
            })
            .OrderByDescending(x => x.CompletionRate);

        return Results.Ok(grouped);
    });


    }

    /* ============================
       HELPERS
       ============================ */
    private static Guid? GetUserId(ClaimsPrincipal user)
    {
        var id = user.FindFirstValue(ClaimTypes.NameIdentifier);
        return Guid.TryParse(id, out var guid) ? guid : null;
    }

    private static bool IsAdmin(ClaimsPrincipal user)
    {
        return user.IsInRole(UserRole.Admin);
    }
}
