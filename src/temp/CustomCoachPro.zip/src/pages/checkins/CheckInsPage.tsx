import { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ClipboardCheck, Scale, Camera, Dumbbell, Utensils, Eye, RefreshCw, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { PageHeader } from "@/components/shared/PageHeader";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import checkInService, { CheckIn, CheckInStatus, CheckInType } from "@/services/checkInService";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

const typeIcon = (type: CheckInType) => {
  switch (type) {
    case "weight":
      return Scale;
    case "photos":
      return Camera;
    case "workout":
      return Dumbbell;
    case "diet":
      return Utensils;
    default:
      return ClipboardCheck;
  }
};

const typeLabel = (type: CheckInType) => {
  switch (type) {
    case "weight":
      return "Weight & Measurements";
    case "photos":
      return "Progress Photos";
    case "workout":
      return "Workout";
    case "diet":
      return "Diet";
    default:
      return "Check-in";
  }
};

type TabValue = "pending" | "reviewed" | "all";

export function CheckInsPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const clientId = searchParams.get("clientId") ?? undefined;
  const checkInId = searchParams.get("checkInId") ?? undefined;

  const [activeTab, setActiveTab] = useState<TabValue>("pending");
  const [selected, setSelected] = useState<CheckIn | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  // Auto-open deep-linked check-in ONLY ONCE.
  const [didAutoOpen, setDidAutoOpen] = useState(false);

  // Highlight the last-reviewed row for a short time
  const [highlightCheckInId, setHighlightCheckInId] = useState<string | null>(null);

  // ✅ Step B: review feedback form state
  const [feedbackMessage, setFeedbackMessage] = useState("");
  const [actionItemDraft, setActionItemDraft] = useState("");
  const [actionItems, setActionItems] = useState<string[]>([]);

  const statusFilter: CheckInStatus | undefined = activeTab === "all" ? undefined : (activeTab as CheckInStatus);

  const queryKey = useMemo(() => ["checkins", { statusFilter, clientId }], [statusFilter, clientId]);

  const {
    data: checkIns = [],
    isLoading,
    isError,
    refetch,
  } = useQuery({
    queryKey,
    queryFn: () =>
      checkInService.getCheckIns({ status: statusFilter, clientId, sortBy: "submittedAt", sortDirection: "desc" }),
  });

  const clearDeepLink = () => {
    if (!checkInId) return;
    const next = new URLSearchParams(searchParams);
    next.delete("checkInId");
    setSearchParams(next, { replace: true });
  };

  const pulseHighlight = (id: string) => {
    setHighlightCheckInId(id);
    window.setTimeout(() => {
      setHighlightCheckInId((prev) => (prev === id ? null : prev));
    }, 2000);
  };

  const resetReviewForm = () => {
    setFeedbackMessage("");
    setActionItemDraft("");
    setActionItems([]);
  };

  const markReviewed = useMutation({
    mutationFn: async (id: string) => {
      const payload = {
        feedbackMessage: feedbackMessage.trim() ? feedbackMessage.trim() : undefined,
        actionItems: actionItems.length ? actionItems : undefined,
      };
      return checkInService.markReviewed(id, payload);
    },
    onSuccess: async (_updated) => {
      if (selected?.id) pulseHighlight(selected.id);

      await queryClient.invalidateQueries({ queryKey: ["checkins"] });
      await queryClient.invalidateQueries({ queryKey: ["dashboard", "coach"] });

      toast({ title: "Reviewed + feedback sent" });

      clearDeepLink();
      setDialogOpen(false);
      resetReviewForm();

      if (activeTab === "pending") setActiveTab("reviewed");
    },
    onError: () => toast({ title: "Unable to review check-in", variant: "destructive" }),
  });

  // Auto-open the check-in from notification deep-link.
  useEffect(() => {
    if (!checkInId) return;
    if (didAutoOpen) return;

    const found = checkIns.find((c) => c.id === checkInId);
    if (found) {
      setSelected(found);
      setDialogOpen(true);
      setDidAutoOpen(true);
    }
  }, [checkInId, didAutoOpen, checkIns]);

  const openCheckIn = (ci: CheckIn) => {
    setSelected(ci);
    setDialogOpen(true);

    // If it’s pending, start with empty form; if reviewed, show existing feedback (read-only)
    resetReviewForm();
  };

  const renderRow = (ci: CheckIn) => {
    const Icon = typeIcon(ci.type);
    const isPending = ci.status === "pending";
    const isHighlighted = highlightCheckInId === ci.id;

    return (
      <Card
        key={ci.id}
        className={[
          "cursor-pointer transition-colors",
          "hover:border-primary/40 hover:bg-muted/30",
          isHighlighted ? "border-primary/60 bg-primary/5" : "",
        ].join(" ")}
        onClick={() => openCheckIn(ci)}
      >
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={ci.clientAvatar ?? undefined} />
                <AvatarFallback className="bg-primary/10 text-primary">
                  {(ci.clientName?.[0] ?? "C").toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium text-foreground">{ci.clientName}</p>
                <p className="text-sm text-muted-foreground">
                  {typeLabel(ci.type)} • {new Date(ci.submittedAt).toLocaleString()}
                </p>
              </div>
            </div>

            <div className="text-right">
              <Badge className={isPending ? "bg-energy/15 text-energy border-0" : "bg-vitality/20 text-vitality border-0"}>
                {ci.status}
              </Badge>
              <div className="mt-2 flex items-center justify-end gap-2">
                <div className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center">
                  <Icon className="h-4 w-4 text-muted-foreground" />
                </div>
                <Badge variant="outline">{ci.type}</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const addActionItem = () => {
    const v = actionItemDraft.trim();
    if (!v) return;

    setActionItems((prev) => {
      const merged = [...prev, v];
      // keep unique, stable order
      const out: string[] = [];
      for (const item of merged) {
        const norm = item.trim().toLowerCase();
        if (!out.some((x) => x.trim().toLowerCase() === norm)) out.push(item.trim());
      }
      return out;
    });

    setActionItemDraft("");
  };

  const removeActionItem = (idx: number) => {
    setActionItems((prev) => prev.filter((_, i) => i !== idx));
  };

  const renderDetails = (ci: CheckIn) => {
    const isPending = ci.status === "pending";
    const canReview = user?.role === "coach" && isPending;

    const rows: { label: string; value: string }[] = [];

    if (ci.type === "weight") {
      if (ci.data.weight != null) rows.push({ label: "Weight", value: String(ci.data.weight) });
      if (ci.data.bodyFat != null) rows.push({ label: "Body fat", value: String(ci.data.bodyFat) });
      if (ci.data.waist != null) rows.push({ label: "Waist", value: String(ci.data.waist) });
      if (ci.data.chest != null) rows.push({ label: "Chest", value: String(ci.data.chest) });
      if (ci.data.arms != null) rows.push({ label: "Arms", value: String(ci.data.arms) });
      if (ci.data.thighs != null) rows.push({ label: "Thighs", value: String(ci.data.thighs) });
    }

    if (ci.type === "workout") {
      if (ci.data.completed != null) rows.push({ label: "Completed", value: ci.data.completed ? "Yes" : "No" });
      if (ci.data.workoutNotes) rows.push({ label: "Workout notes", value: ci.data.workoutNotes });
    }

    if (ci.type === "diet") {
      if (ci.data.complianceRating != null) rows.push({ label: "Compliance", value: `${ci.data.complianceRating}/100` });
      if (ci.data.deviations) rows.push({ label: "Deviations", value: ci.data.deviations });
    }

    if (ci.type === "photos") {
      const front = ci.data.photos?.front ?? (ci as any)?.data?.frontPhotoUrl ?? null;
      const side = ci.data.photos?.side ?? (ci as any)?.data?.sidePhotoUrl ?? null;
      const back = ci.data.photos?.back ?? (ci as any)?.data?.backPhotoUrl ?? null;

      if (front) rows.push({ label: "Front photo", value: String(front) });
      if (side) rows.push({ label: "Side photo", value: String(side) });
      if (back) rows.push({ label: "Back photo", value: String(back) });
    }

    if (ci.notes) rows.push({ label: "Notes", value: ci.notes });

    const existingFeedback = ci.coachFeedback?.trim() ?? "";
    const existingItems = Array.isArray(ci.actionItems) ? ci.actionItems : [];

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium text-foreground">{ci.clientName}</p>
            <p className="text-sm text-muted-foreground">
              {typeLabel(ci.type)} • {new Date(ci.submittedAt).toLocaleString()}
            </p>
          </div>
          <Badge className={isPending ? "bg-energy/15 text-energy border-0" : "bg-vitality/20 text-vitality border-0"}>
            {ci.status}
          </Badge>
        </div>

        {rows.length === 0 ? (
          <p className="text-sm text-muted-foreground">No details captured for this check-in.</p>
        ) : (
          <div className="space-y-2">
            {rows.map((r) => (
              <div key={r.label} className="flex items-start justify-between gap-4 border rounded-lg p-3">
                <p className="text-sm font-medium text-foreground">{r.label}</p>
                <p className="text-sm text-muted-foreground break-all text-right">{r.value}</p>
              </div>
            ))}
          </div>
        )}

        {/* ✅ Step B: Show existing feedback when already reviewed */}
        {!isPending && (existingFeedback || existingItems.length > 0) ? (
          <div className="rounded-xl border p-3 space-y-2">
            <p className="text-sm font-medium text-foreground">Coach feedback</p>
            {existingFeedback ? (
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">{existingFeedback}</p>
            ) : (
              <p className="text-sm text-muted-foreground">—</p>
            )}

            <p className="text-sm font-medium text-foreground mt-2">Action items</p>
            {existingItems.length ? (
              <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
                {existingItems.map((it, idx) => (
                  <li key={`${it}-${idx}`}>{it}</li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-muted-foreground">—</p>
            )}
          </div>
        ) : null}

        {/* ✅ Step B: Coach-only review form (pending only) */}
        {canReview ? (
          <div className="rounded-xl border p-3 space-y-3">
            <div>
              <p className="text-sm font-medium text-foreground">Feedback (client-visible)</p>
              <textarea
                value={feedbackMessage}
                onChange={(e) => setFeedbackMessage(e.target.value)}
                placeholder="Write feedback for the client..."
                className="mt-2 w-full min-h-[90px] rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </div>

            <div>
              <p className="text-sm font-medium text-foreground">Action items (client-visible)</p>

              <div className="mt-2 flex gap-2">
                <Input
                  value={actionItemDraft}
                  onChange={(e) => setActionItemDraft(e.target.value)}
                  placeholder='Add action item (e.g., "hit 8k steps")'
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addActionItem();
                    }
                  }}
                />
                <Button type="button" variant="outline" onClick={addActionItem} disabled={!actionItemDraft.trim()}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add
                </Button>
              </div>

              {actionItems.length ? (
                <div className="mt-3 space-y-2">
                  {actionItems.map((it, idx) => (
                    <div key={`${it}-${idx}`} className="flex items-center justify-between gap-2 rounded-lg border p-2">
                      <p className="text-sm text-muted-foreground">{it}</p>
                      <Button type="button" variant="ghost" size="sm" onClick={() => removeActionItem(idx)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="mt-2 text-xs text-muted-foreground">No action items added yet.</p>
              )}
            </div>
          </div>
        ) : null}

        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => navigate(`/clients/${ci.clientId}`)}>
            Open client
          </Button>

          {canReview && (
            <Button
              onClick={() => markReviewed.mutate(ci.id)}
              disabled={markReviewed.isPending}
              className="shadow-energy"
              title="Marks reviewed + sends feedback to client"
            >
              {markReviewed.isPending ? "Sending…" : "Send feedback & mark reviewed"}
            </Button>
          )}
        </div>
      </div>
    );
  };

  const handleTabChange = (v: string) => {
    setActiveTab(v as TabValue);

    // Tab switching should show lists, not reopen deep-linked dialog.
    if (checkInId) {
      clearDeepLink();
      setDialogOpen(false);
    }
  };

  const handleDialogOpenChange = (open: boolean) => {
    setDialogOpen(open);

    // Closing dialog should remove checkInId so it doesn't reopen later.
    if (!open && checkInId) {
      clearDeepLink();
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Check-ins"
        description="Review and track client check-ins."
        actions={
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => refetch()} disabled={isLoading}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="outline" onClick={() => navigate("/clients")}>
              View clients
            </Button>
          </div>
        }
      />

      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-4">
        <TabsList>
          <TabsTrigger value="pending" className="flex items-center gap-2">
            <ClipboardCheck className="h-4 w-4" />
            Pending
          </TabsTrigger>
          <TabsTrigger value="reviewed" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            Reviewed
          </TabsTrigger>
          <TabsTrigger value="all" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            All
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-4">
          {isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, idx) => (
                <Skeleton key={idx} className="h-20 w-full rounded-xl" />
              ))}
            </div>
          ) : isError ? (
            <p className="text-sm text-destructive">Unable to load check-ins right now.</p>
          ) : checkIns.length === 0 ? (
            <p className="text-sm text-muted-foreground">No check-ins found.</p>
          ) : (
            <div className="space-y-3">{checkIns.map(renderRow)}</div>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={dialogOpen} onOpenChange={handleDialogOpenChange}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Check-in details</DialogTitle>
            <DialogDescription>Review what the client submitted and send feedback.</DialogDescription>
          </DialogHeader>
          {selected ? renderDetails(selected) : <p className="text-sm text-muted-foreground">Select a check-in.</p>}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default CheckInsPage;
