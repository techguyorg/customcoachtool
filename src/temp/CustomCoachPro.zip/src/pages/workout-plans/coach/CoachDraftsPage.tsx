import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Trash2, Pencil, Upload } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import workoutPlanService from "@/services/workoutPlanService";
import type { WorkoutPlan } from "@/types";

export default function CoachDraftsPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["workout-plans"],
    queryFn: () => workoutPlanService.list(),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => workoutPlanService.remove(id),
    onSuccess: () => {
      toast({ title: "Draft deleted" });
      queryClient.invalidateQueries({ queryKey: ["workout-plans"] });
    },
  });

  const publishMutation = useMutation({
    mutationFn: (id: string) =>
      workoutPlanService.update(id, { isPublished: true }),
    onSuccess: () => {
      toast({ title: "Plan published" });
      queryClient.invalidateQueries({ queryKey: ["workout-plans"] });
    },
  });

  if (!user) return null;

  const drafts = plans
    .filter((p) => p.coachId === user.id && !p.isPublished)
    .sort(
      (a, b) =>
        new Date(b.updatedAt).getTime() -
        new Date(a.updatedAt).getTime()
    );

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold">Draft workout plans</h1>
        <p className="text-sm text-muted-foreground">
          Unpublished plans visible only to you.
        </p>
      </div>

      {isLoading && (
        <Card className="p-6 text-sm text-muted-foreground">
          Loading drafts…
        </Card>
      )}

      {!isLoading && drafts.length === 0 && (
        <Card className="p-6 text-sm text-muted-foreground">
          You have no drafts. Create one to get started.
        </Card>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {drafts.map((plan) => (
          <DraftCard
            key={plan.id}
            plan={plan}
            onEdit={() =>
              navigate(`/workout-plans/${plan.id}/edit`)
            }
            onPublish={() => publishMutation.mutate(plan.id)}
            onDelete={() => {
              if (
                confirm(
                  "This will permanently delete the draft. Continue?"
                )
              ) {
                deleteMutation.mutate(plan.id);
              }
            }}
          />
        ))}
      </div>
    </div>
  );
}

/* -----------------------------
   Draft Card
------------------------------ */

function DraftCard({
  plan,
  onEdit,
  onPublish,
  onDelete,
}: {
  plan: WorkoutPlan;
  onEdit: () => void;
  onPublish: () => void;
  onDelete: () => void;
}) {
  return (
    <Card className="p-4 space-y-3">
      <div className="font-medium">{plan.name}</div>
      <div className="text-xs text-muted-foreground">
        {plan.durationWeeks} weeks · {plan.days.length} days
      </div>

      <div className="flex gap-2 pt-2">
        <Button size="sm" variant="outline" onClick={onEdit}>
          <Pencil className="h-4 w-4 mr-1" />
          Edit
        </Button>

        <Button size="sm" onClick={onPublish}>
          <Upload className="h-4 w-4 mr-1" />
          Publish
        </Button>

        <Button
          size="sm"
          variant="ghost"
          className="text-destructive ml-auto"
          onClick={onDelete}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </Card>
  );
}
