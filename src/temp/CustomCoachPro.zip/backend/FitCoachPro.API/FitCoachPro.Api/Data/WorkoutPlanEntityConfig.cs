using FitCoachPro.Api.Models.WorkoutPlans;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FitCoachPro.Api.Data;

public class WorkoutPlanEntityConfig : IEntityTypeConfiguration<WorkoutPlanEntity>
{
    public void Configure(EntityTypeBuilder<WorkoutPlanEntity> builder)
    {
        builder.ToTable("WorkoutPlanDocuments");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.DefinitionJson)
            .IsRequired()
            .HasColumnType("nvarchar(max)");

        builder.HasIndex(x => x.CoachId);
        builder.HasIndex(x => x.Name);
    }
}
