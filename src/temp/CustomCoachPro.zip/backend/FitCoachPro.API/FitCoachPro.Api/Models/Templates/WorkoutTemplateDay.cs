using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models.Templates;

public class WorkoutTemplateDay
{
    public Guid Id { get; set; } = Guid.NewGuid();

    public Guid WorkoutTemplateId { get; set; }
    public WorkoutTemplate WorkoutTemplate { get; set; } = null!;

    public int DayIndex { get; set; } // 1..7

    [MaxLength(128)]
    public string? Title { get; set; } // e.g., "Upper", "Lower", "Push", "Pull", "Legs"

    public ICollection<WorkoutTemplateExercise> Exercises { get; set; } = new List<WorkoutTemplateExercise>();
}
