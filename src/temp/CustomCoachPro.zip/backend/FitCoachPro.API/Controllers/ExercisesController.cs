using FitCoachPro.Api.Data;
using FitCoachPro.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers;

[ApiController]
[Route("api/exercises")]
public class ExercisesController : ControllerBase
{
    private readonly AppDbContext _db;

    public ExercisesController(AppDbContext db)
    {
        _db = db;
    }

    // -----------------------------
    // GET: api/exercises
    // Supports search + muscle filter
    // -----------------------------
    [HttpGet]
    public async Task<IActionResult> GetExercises(
        [FromQuery] string? search,
        [FromQuery] string? muscle)
    {
        IQueryable<Exercise> query = _db.Exercises;

        if (!string.IsNullOrWhiteSpace(search))
        {
            query = query.Where(x =>
                x.Name.ToLower().Contains(search.ToLower()));
        }

        if (!string.IsNullOrWhiteSpace(muscle))
        {
            query = query.Where(x =>
                x.PrimaryMuscleGroup != null &&
                x.PrimaryMuscleGroup.ToLower() == muscle.ToLower());
        }

        var result = await query
            .OrderBy(x => x.Name)
            .ToListAsync();

        return Ok(result);
    }

    // -----------------------------
    // POST: api/exercises
    // Create new exercise (coach)
    // -----------------------------
    [HttpPost]
    public async Task<IActionResult> CreateExercise([FromBody] Exercise exercise)
    {
        exercise.Id = Guid.NewGuid();
        exercise.CreatedAt = DateTime.UtcNow;
        exercise.UpdatedAt = DateTime.UtcNow;
        exercise.IsPublished = true;

        _db.Exercises.Add(exercise);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetExerciseById),
            new { id = exercise.Id }, exercise);
    }

    // -----------------------------
    // GET: api/exercises/{id}
    // -----------------------------
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetExerciseById(Guid id)
    {
        var exercise = await _db.Exercises.FindAsync(id);
        if (exercise == null)
            return NotFound();

        return Ok(exercise);
    }

    // -----------------------------
    // PUT: api/exercises/{id}
    // Update existing exercise
    // -----------------------------
    [HttpPut("{id:guid}")]
    public async Task<IActionResult> UpdateExercise(
        Guid id,
        [FromBody] Exercise updated)
    {
        var existing = await _db.Exercises.FindAsync(id);
        if (existing == null)
            return NotFound();

        existing.Name = updated.Name;
        existing.Description = updated.Description;
        existing.PrimaryMuscleGroup = updated.PrimaryMuscleGroup;
        existing.SecondaryMuscles = updated.SecondaryMuscles;
        existing.Equipment = updated.Equipment;
        existing.VideoUrl = updated.VideoUrl;
        existing.IsPublished = updated.IsPublished;
        existing.UpdatedAt = DateTime.UtcNow;

        await _db.SaveChangesAsync();
        return Ok(existing);
    }
}
