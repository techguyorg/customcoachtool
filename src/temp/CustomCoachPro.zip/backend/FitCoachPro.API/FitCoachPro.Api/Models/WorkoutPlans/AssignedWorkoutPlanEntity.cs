using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models.WorkoutPlans;

public class AssignedWorkoutPlanEntity
{
    [Key]
    public Guid Id { get; set; }

    // Ownership
    public Guid ClientId { get; set; }
    public Guid CoachId { get; set; }

    // Reference (informational only)
    public Guid TemplatePlanId { get; set; }

    // Snapshot of WorkoutPlanDocument at assignment time
    [Required]
    public string DefinitionJson { get; set; } = "";

    // Lifecycle
    public DateTime AssignedAt { get; set; }
    public DateTime? StartsOn { get; set; }
    public DateTime? EndsOn { get; set; }

    // State
    public bool IsActive { get; set; } = true;
}
