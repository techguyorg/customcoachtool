import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Pencil, Copy, Dumbbell, ShieldCheck } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { PageHeader } from "@/components/shared/PageHeader";
import { EmptyState } from "@/components/shared/EmptyState";

import workoutPlanService from "@/services/workoutPlanService";
import type { WorkoutPlan } from "@/types";

/* -----------------------------------------------------
   READ-ONLY WORKOUT PLAN VIEWER
   -----------------------------------------------------
   - Used by coaches, future clients, and admins
   - System plans are admin-owned and immutable
----------------------------------------------------- */

export default function WorkoutPlanViewerPage() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();

  const { data: plan, isLoading } = useQuery({
    queryKey: ["workout-plan-view", id],
    queryFn: () => workoutPlanService.get(id!),
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto py-10 space-y-4">
        <div className="h-8 w-1/2 bg-muted rounded animate-pulse" />
        <div className="h-4 w-1/3 bg-muted rounded animate-pulse" />
        <div className="h-32 bg-muted rounded animate-pulse" />
      </div>
    );
  }

  if (!plan) {
    return (
      <EmptyState
        icon={Dumbbell}
        title="Workout plan not found"
        description="The plan you are trying to view does not exist."
        actionLabel="Back to workout programs"
        onAction={() => navigate("/workout-plans")}
      />
    );
  }

  /* -----------------------------------------------------
     SYSTEM VS CUSTOM PLAN DETECTION
  ----------------------------------------------------- */
  const isSystemPlan =
    plan.coachId === "00000000-0000-0000-0000-000000000000";

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-in">
      {/* HEADER */}
      <PageHeader
        title={plan.name}
        description={plan.description || "Workout program overview"}
        actions={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>

            {/* Edit only for non-system plans */}
            {!isSystemPlan && (
              <Button
                variant="outline"
                onClick={() =>
                  navigate(`/workout-plans/${plan.id}/edit`)
                }
              >
                <Pencil className="h-4 w-4 mr-2" />
                Edit
              </Button>
            )}

            {/* Always allowed — but explicit */}
            <Button
              onClick={async () => {
                const { id } = await workoutPlanService.create({
                  name: `${plan.name} (Copy)`,
                  description: plan.description,
                  durationWeeks: plan.durationWeeks,
                  days: plan.days,
                });

                navigate(`/workout-plans/${id}/edit`);
              }}
            >
              <Copy className="h-4 w-4 mr-2" />
              Use as starting point
            </Button>
          </div>
        }
      />

      {/* META */}
      <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
        <span>{plan.durationWeeks} weeks</span>
        <span>·</span>
        <span>{plan.days.length} days</span>

        {isSystemPlan && (
          <>
            <span>·</span>
            <span className="opacity-70 flex items-center gap-1">
              <ShieldCheck className="h-4 w-4" />
              Admin-curated template
            </span>
          </>
        )}
      </div>

      <Separator />

      {/* SYSTEM PLAN CONTEXT */}
      {isSystemPlan && (
        <Card className="border-dashed bg-muted/30">
          <CardContent className="p-4 text-sm text-muted-foreground">
            This is a professionally designed workout template maintained by
            platform administrators. You can safely use it as-is or create a
            copy to customize for your own needs.
          </CardContent>
        </Card>
      )}

      {/* PLAN STRUCTURE */}
      <div className="space-y-6">
        {plan.days
          .slice()
          .sort((a, b) => a.dayNumber - b.dayNumber)
          .map((day) => (
            <Card key={day.id}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Dumbbell className="h-5 w-5 text-icon-workout" />
                  Day {day.dayNumber}: {day.name}
                </CardTitle>
                <CardDescription>
                  {day.exercises.length} exercises
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-3">
                {day.exercises
                  .slice()
                  .sort((a, b) => a.order - b.order)
                  .map((ex) => (
                    <div
                      key={ex.id}
                      className="flex items-start justify-between border-b last:border-none pb-2"
                    >
                      <div className="space-y-1">
                        <div className="font-medium text-sm">
                          {ex.name}
                        </div>
                        {ex.notes && (
                          <div className="text-xs text-muted-foreground">
                            {ex.notes}
                          </div>
                        )}
                      </div>

                      <div className="text-xs text-muted-foreground text-right">
                        <div>
                          {ex.sets} × {ex.reps}
                        </div>
                        {ex.restSeconds ? (
                          <div>{ex.restSeconds}s rest</div>
                        ) : null}
                      </div>
                    </div>
                  ))}
              </CardContent>
            </Card>
          ))}
      </div>
    </div>
  );
}
