using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models.Workouts;

public class WorkoutSessionEntity
{
    [Key]
    public Guid Id { get; set; }

    // Ownership
    public Guid ClientId { get; set; }
    public Guid CoachId { get; set; }

    // Reference to assigned plan
    public Guid AssignedWorkoutPlanId { get; set; }

    // Optional: which day of the plan this session belongs to
    public int? PlanDayOrder { get; set; }

    // Snapshot of what was actually performed
    [Required]
    public string PerformedWorkoutJson { get; set; } = "";

    // Timing
    public DateTime StartedAt { get; set; }
    public DateTime? EndedAt { get; set; }

    // State
    public bool IsCompleted { get; set; }
}
