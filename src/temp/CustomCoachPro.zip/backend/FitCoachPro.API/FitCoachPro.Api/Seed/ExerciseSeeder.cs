using System.Text.Json;
using FitCoachPro.Api.Data;
using FitCoachPro.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace FitCoachPro.Api.Seed;

public static class ExerciseSeeder
{
    public static async Task SeedAsync(AppDbContext db, IWebHostEnvironment env)
    {
        // Safety check: do nothing if exercises already exist
        if (await db.Exercises.AnyAsync())
            return;

        var seedFilePath = Path.Combine(
            env.ContentRootPath,
            "SeedContent",
            "exercises.json"
        );

        if (!File.Exists(seedFilePath))
            throw new FileNotFoundException(
                "Exercise seed file not found",
                seedFilePath
            );

        var json = await File.ReadAllTextAsync(seedFilePath);

        var exercises = JsonSerializer.Deserialize<List<Exercise>>(
            json,
            new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            }
        );

        if (exercises == null || exercises.Count == 0)
            return;

        foreach (var exercise in exercises)
        {
            exercise.Id = Guid.NewGuid();
            exercise.CreatedAt = DateTime.UtcNow;
            exercise.UpdatedAt = DateTime.UtcNow;
            exercise.IsPublished = true;
        }

        db.Exercises.AddRange(exercises);
        await db.SaveChangesAsync();
    }
}
