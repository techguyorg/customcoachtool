import { Plus, LayoutGrid } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import workoutPlanService from "@/services/workoutPlanService";
import type { WorkoutPlan } from "@/types";

export default function CoachWorkoutDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ["workout-plans"],
    queryFn: () => workoutPlanService.list(),
  });

  if (!user) return null;

  const drafts = plans.filter(
    (p) => p.coachId === user.id && !p.isPublished
  );

  const templates = plans.filter(
    (p) => p.coachId === user.id && p.isPublished
  );

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Workout Plans</h1>
          <p className="text-sm text-muted-foreground">
            Create, manage, and reuse your workout programs.
          </p>
        </div>

        <div className="flex gap-2">
          <Button onClick={() => navigate("/workout-plans/new")}>
            <Plus className="h-4 w-4 mr-2" />
            Create plan
          </Button>

          <Button
            variant="outline"
            onClick={() => navigate("/workout-templates")}
          >
            <LayoutGrid className="h-4 w-4 mr-2" />
            Templates
          </Button>
        </div>
      </div>

      {/* Drafts */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium">
            Drafts ({drafts.length})
          </h2>
          {drafts.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/workout-plans/coach/drafts")}
            >
              View all
            </Button>
          )}
        </div>

        {isLoading ? (
          <Card className="p-6 text-sm text-muted-foreground">
            Loading drafts…
          </Card>
        ) : drafts.length === 0 ? (
          <Card className="p-6 text-sm text-muted-foreground">
            Drafts let you experiment before publishing plans.
          </Card>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {drafts.slice(0, 3).map((plan) => (
              <PlanPreviewCard
                key={plan.id}
                plan={plan}
                onClick={() =>
                  navigate(`/workout-plans/${plan.id}/edit`)
                }
              />
            ))}
          </div>
        )}
      </section>

      {/* Templates */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium">
            Templates ({templates.length})
          </h2>
          {templates.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() =>
                navigate("/workout-plans/coach/templates")
              }
            >
              View all
            </Button>
          )}
        </div>

        {isLoading ? (
          <Card className="p-6 text-sm text-muted-foreground">
            Loading templates…
          </Card>
        ) : templates.length === 0 ? (
          <Card className="p-6 text-sm text-muted-foreground">
            Published plans appear here for reuse and assignment.
          </Card>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {templates.slice(0, 3).map((plan) => (
              <PlanPreviewCard
                key={plan.id}
                plan={plan}
                onClick={() =>
                  navigate(`/workout-plans/${plan.id}`)
                }
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

/* -----------------------------
   Minimal internal card
------------------------------ */

function PlanPreviewCard({
  plan,
  onClick,
}: {
  plan: WorkoutPlan;
  onClick: () => void;
}) {
  return (
    <Card
      className="p-4 cursor-pointer hover:shadow-md transition"
      onClick={onClick}
    >
      <div className="font-medium">{plan.name}</div>
      <div className="text-xs text-muted-foreground mt-1">
        {plan.durationWeeks} weeks · {plan.days.length} days
      </div>
    </Card>
  );
}
