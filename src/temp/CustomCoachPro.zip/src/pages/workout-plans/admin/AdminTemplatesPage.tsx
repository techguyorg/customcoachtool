import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import workoutPlanService from "@/services/workoutPlanService";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const EMPTY_GUID = "00000000-0000-0000-0000-000000000000";

export default function AdminTemplatesPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data = [], isLoading } = useQuery({
    queryKey: ["admin-templates"],
    queryFn: () => workoutPlanService.list(),
  });

  const templates = data.filter(
    (p) => p.coachId === EMPTY_GUID
  );

  const updateMutation = useMutation({
    mutationFn: ({ id, publish }: { id: string; publish: boolean }) =>
      workoutPlanService.update(id, { isPublished: publish }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-templates"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => workoutPlanService.remove(id),
    onSuccess: () => {
      toast({ title: "Template deleted" });
      qc.invalidateQueries({ queryKey: ["admin-templates"] });
    },
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="text-2xl font-semibold">
        Platform workout templates
      </h1>

      {isLoading && <Card className="p-6">Loading…</Card>}

      <div className="grid gap-4">
        {templates.map((plan) => (
          <Card key={plan.id} className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">{plan.name}</div>
                <div className="text-sm text-muted-foreground">
                  {plan.durationWeeks} weeks
                </div>
              </div>

              <Badge variant={plan.isPublished ? "default" : "secondary"}>
                {plan.isPublished ? "Published" : "Draft"}
              </Badge>
            </div>

            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() =>
                  navigate(`/workout-plans/${plan.id}/edit`)
                }
              >
                Edit
              </Button>

              <Button
                size="sm"
                variant="outline"
                onClick={() =>
                  updateMutation.mutate({
                    id: plan.id,
                    publish: !plan.isPublished,
                  })
                }
              >
                {plan.isPublished ? "Unpublish" : "Publish"}
              </Button>

              <Button
                size="sm"
                variant="destructive"
                onClick={() => {
                  if (!confirm("Delete this template permanently?")) return;
                  deleteMutation.mutate(plan.id);
                }}
              >
                Delete
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
