import fs from "node:fs";
import path from "node:path";

type ExerciseSeed = {
  slug: string;
  name: string;
  primaryMuscleGroup: string;
  secondaryMuscles: string[];
  equipment: string[];
  movementPattern: string;
  tags: string[];
};

const API_BASE = process.env.API_BASE ?? "http://localhost:5000";
const TOKEN = process.env.SEED_TOKEN ?? ""; // coach/admin token

async function upsertExercise(item: ExerciseSeed) {
  const res = await fetch(`${API_BASE}/api/exercises/upsert`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(TOKEN ? { authorization: `Bearer ${TOKEN}` } : {}),
    },
    body: JSON.stringify(item),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Upsert failed for ${item.slug}: ${res.status} ${text}`);
  }
}

async function main() {
  const file = path.join(process.cwd(), "src", "seed", "exercises.v1.json");
  const raw = fs.readFileSync(file, "utf-8");
  const items = JSON.parse(raw) as ExerciseSeed[];

  console.log(`Seeding ${items.length} exercises...`);
  for (const item of items) {
    await upsertExercise(item);
  }
  console.log("Done.");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
