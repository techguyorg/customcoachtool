namespace FitCoachPro.Api.Models.WorkoutPlans;
using System.Text.Json;


public class WorkoutPlanDocument
{
    public WorkoutPlanMeta Meta { get; set; } = new();
    public List<WorkoutPlanDay> Days { get; set; } = new();
}

public class WorkoutPlanMeta
{
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public int DurationWeeks { get; set; }
    public string Goal { get; set; } = "general";
    public bool IsPublished { get; set; }
}

public class WorkoutPlanDay
{
    public string Name { get; set; } = "";
    public int Order { get; set; }
    public List<WorkoutPlanExercise> Exercises { get; set; } = new();
}

public class WorkoutPlanExercise
{
    public Guid? LibraryExerciseId { get; set; }   // optional
    public string Name { get; set; } = "";         // always present
    public int Sets { get; set; }
    public string Reps { get; set; } = "";
    public int RestSeconds { get; set; }
    public string? Tempo { get; set; }
    public string? Notes { get; set; }
    public int Order { get; set; }
}

public static class WorkoutPlanDocumentJson
{
    public static WorkoutPlanDocument? TryDeserialize(string json)
    {
        try
        {
            return JsonSerializer.Deserialize<WorkoutPlanDocument>(json);
        }
        catch
        {
            return null;
        }
    }
}
