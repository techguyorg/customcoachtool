import { useEffect, useState } from "react";
import { getExercises } from "../../services/exerciseService";
import type { Exercise } from "@/types";

interface Props {
  onSelect: (exercise: Exercise) => void;
}

export default function ExerciseExplorer({ onSelect }: Props) {
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [search, setSearch] = useState("");
  const [muscleGroup, setMuscle] = useState("");

  useEffect(() => {
    loadExercises();
  }, [search, muscleGroup]);

  async function loadExercises() {
    const data = await getExercises({ search, muscleGroup});
    setExercises(data);
  }

  return (
    <div className="w-96 border-r bg-gray-50 p-4 overflow-y-auto">
      <h2 className="text-lg font-semibold mb-4">Exercise Library</h2>

      {/* Search */}
      <input
        type="text"
        placeholder="Search exercise..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full mb-3 px-3 py-2 border rounded"
      />

      {/* Muscle Filter */}
      <select
        value={muscleGroup}
        onChange={(e) => setMuscle(e.target.value)}
        className="w-full mb-4 px-3 py-2 border rounded"
      >
        <option value="">All muscles</option>
        <option value="Chest">Chest</option>
        <option value="Back">Back</option>
        <option value="Shoulders">Shoulders</option>
        <option value="Biceps">Biceps</option>
        <option value="Triceps">Triceps</option>
        <option value="Quadriceps">Quadriceps</option>
        <option value="Hamstrings">Hamstrings</option>
        <option value="Glutes">Glutes</option>
        <option value="Calves">Calves</option>
        <option value="Abs">Abs</option>
        <option value="Full Body">Full Body</option>
      </select>

      {/* Exercise List */}
      <div className="space-y-2">
        {exercises.map((ex) => (
          <div
            key={ex.id}
            className="p-2 border rounded bg-white flex justify-between items-center"
          >
            <div>
              <div className="font-medium">{ex.name}</div>
              <div className="text-xs text-gray-500">
                {ex.muscleGroups?.join(", ")} • {ex.equipment}
              </div>
            </div>

            <button
              onClick={() => onSelect(ex)}
              className="text-sm px-2 py-1 bg-blue-600 text-white rounded"
            >
              Add
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
