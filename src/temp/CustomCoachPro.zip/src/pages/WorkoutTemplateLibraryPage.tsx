import { useEffect, useState } from "react";
import { getWorkoutTemplates, cloneWorkoutTemplate } from "@/services/workoutTemplateService";

export default function WorkoutTemplateLibraryPage() {
  const [templates, setTemplates] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getWorkoutTemplates()
      .then(setTemplates)
      .finally(() => setLoading(false));
  }, []);

  const handleClone = async (id: string) => {
    await cloneWorkoutTemplate(id);
    alert("Template cloned. You can now edit it in Workout Plans.");
  };

  if (loading) return <div>Loading templates...</div>;

  return (
    <div>
      <h1>Workout Plan Templates</h1>

      {templates.map(t => (
        <div key={t.id} className="border p-4 mb-4 rounded">
          <h2>{t.name}</h2>
          <p>{t.description}</p>
          <p>{t.durationWeeks} weeks</p>

          <button onClick={() => handleClone(t.id)}>
            Use This Template
          </button>
        </div>
      ))}
    </div>
  );
}
