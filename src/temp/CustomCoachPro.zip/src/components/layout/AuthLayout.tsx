import { Outlet } from 'react-router-dom';

export function AuthLayout() {
  return (
    <div className="min-h-screen flex">
      {/* Left Side - Branding (Desktop only) */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-slate-900">
        <div className="relative z-10 flex flex-col justify-center p-12 text-white">
          <div className="flex items-center gap-3 mb-8">
            <div className="relative">
              <div className="absolute inset-0 -z-10 rounded-full bg-white/10 blur-lg" />
              <img
                src="/logo.png"
                alt="FitCoach Pro"
                className="h-14 w-14 object-contain"
              />
            </div>
            <span className="font-display text-3xl font-bold">
              FitCoach<span className="opacity-80">Pro</span>
            </span>
          </div>

          <h1 className="text-4xl font-display font-bold mb-4 leading-tight">
            Run Your Coaching
            <br />
            With Structure & Clarity
          </h1>

          <p className="text-lg opacity-90 max-w-md leading-relaxed">
            A professional platform for coaches to manage clients, track progress,
            and deliver structured training and nutrition programs.
          </p>

          <div className="mt-12 grid grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold">500+</div>
              <div className="text-sm opacity-80">Active Coaches</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">10k+</div>
              <div className="text-sm opacity-80">Clients Managed</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">95%</div>
              <div className="text-sm opacity-80">Success Rate</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Auth Form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-background">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center justify-center gap-3 mb-8">
            <img
              src="/logo.png"
              alt="FitCoach Pro"
              className="h-12 w-12 object-contain"
            />
            <span className="font-display text-2xl font-bold text-foreground">
              FitCoach<span className="text-primary">Pro</span>
            </span>
          </div>

          <Outlet />
        </div>
      </div>
    </div>
  );
}

export default AuthLayout;
