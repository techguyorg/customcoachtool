# Decision 0001 – Two-Sided Marketplace

## Context
We debated coach-first vs two-sided platform.

## Decision
We chose a two-sided marketplace:
- Clients can self-serve
- Coaches remain a premium layer

## Consequences
- Clients see templates
- Clients can create personal plans
- UI must support non-coach flows

## Status
Accepted – Do not revisit unless monetization strategy changes
