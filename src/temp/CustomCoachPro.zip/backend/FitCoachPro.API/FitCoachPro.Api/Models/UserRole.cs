namespace FitCoachPro.Api.Models;

public static class UserRole
{
    public const string Admin = "Admin";
    public const string Coach = "Coach";
    public const string Client = "Client";
}
