import { WORKOUT_PLANS_NAV } from "@/config/workoutPlansNav";
import { useAuth } from "@/contexts/AuthContext";
import { NavLink } from "react-router-dom";

export default function WorkoutPlansNav() {
  const { user } = useAuth();

  if (!user) return null;

  const items = WORKOUT_PLANS_NAV.filter((i) =>
    i.roles.includes(user.role)
  );

  return (
    <nav className="space-y-1">
      {items.map((item) => (
        <NavLink
          key={item.path}
          to={item.path}
          className={({ isActive }) =>
            [
              "block rounded-md px-3 py-2 text-sm",
              isActive
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-muted",
            ].join(" ")
          }
        >
          {item.label}
        </NavLink>
      ))}
    </nav>
  );
}
