namespace FitCoachPro.Api.Models.Library;

public class ExerciseLibraryItemMuscle
{
    public Guid ExerciseLibraryItemId { get; set; }
    public ExerciseLibraryItem Exercise { get; set; } = null!;

    public Guid ExerciseLibraryMuscleId { get; set; }
    public ExerciseLibraryMuscle Muscle { get; set; } = null!;

    // primary vs secondary
    public bool IsPrimary { get; set; } = false;
}
