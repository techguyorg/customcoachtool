using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models.Library;

public class ExerciseLibraryItem
{
    public Guid Id { get; set; } = Guid.NewGuid();

    // Source metadata (e.g., "wger")
    [MaxLength(32)]
    public string Source { get; set; } = "wger";

    // ID in the upstream source (string because some APIs use int/uuid)
    [MaxLength(64)]
    public string SourceExerciseId { get; set; } = string.Empty;

    [MaxLength(256)]
    public string Name { get; set; } = string.Empty;

    // wger descriptions are HTML-ish sometimes; keep long
    public string? Description { get; set; }

    [MaxLength(64)]
    public string? Category { get; set; } // e.g., "Strength", "Cardio" (depends on source)

    [MaxLength(32)]
    public string? Difficulty { get; set; } // optional, may be null

    // Tags as a simple comma-separated string for now
    [MaxLength(512)]
    public string? Tags { get; set; }

    // Attribution (required for CC-BY-SA compliance)
    [MaxLength(256)]
    public string? AttributionName { get; set; } // e.g., "wger"
    [MaxLength(512)]
    public string? AttributionUrl { get; set; }  // e.g., link to source / exercise page

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<ExerciseLibraryItemMuscle> Muscles { get; set; } = new List<ExerciseLibraryItemMuscle>();
    public ICollection<ExerciseLibraryItemEquipment> Equipment { get; set; } = new List<ExerciseLibraryItemEquipment>();
}
