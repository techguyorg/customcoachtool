using System.ComponentModel.DataAnnotations;

namespace FitCoachPro.Api.Models.Library;

public class ExerciseLibraryMuscle
{
    public Guid Id { get; set; } = Guid.NewGuid();

    [MaxLength(128)]
    public string Name { get; set; } = string.Empty; // e.g., Chest, Lats, Quads

    // Higher-level grouping (your requirement)
    [MaxLength(128)]
    public string MuscleGroup { get; set; } = string.Empty; // e.g., "Chest", "Back", "Legs", "Shoulders", "Arms", "Core"

    public ICollection<ExerciseLibraryItemMuscle> Exercises { get; set; } = new List<ExerciseLibraryItemMuscle>();
}
