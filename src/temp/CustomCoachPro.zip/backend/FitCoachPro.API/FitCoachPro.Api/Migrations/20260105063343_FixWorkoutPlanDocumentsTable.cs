﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FitCoachPro.Api.Migrations
{
    /// <inheritdoc />
    public partial class FixWorkoutPlanDocumentsTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "WorkoutPlanDocuments",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    CoachId = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(maxLength: 200, nullable: false),
                    IsPublished = table.Column<bool>(nullable: false),
                    DefinitionJson = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    UpdatedAt = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkoutPlanDocuments", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_WorkoutPlanDocuments_CoachId",
                table: "WorkoutPlanDocuments",
                column: "CoachId");

            migrationBuilder.CreateIndex(
                name: "IX_WorkoutPlanDocuments_Name",
                table: "WorkoutPlanDocuments",
                column: "Name");
        }


        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(name: "WorkoutPlanDocuments");
        }

    }
}
